import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini API client lazily / safely
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// API: Health check
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// API: Generate AI Itinerary
app.post("/api/itinerary/generate", async (req, res) => {
  try {
    const { destination, days = 3, travelers = "2 Adults", budget = 50000, transport = "Flight", preferences = [] } = req.body;
    const ai = getGeminiClient();

    if (ai) {
      const prompt = `Create a realistic and exciting travel itinerary in India for ${destination}.
Details:
- Duration: ${days} days
- Travelers: ${travelers}
- Transport mode: ${transport}
- Total Budget: ₹${budget}
- Interests: ${preferences.join(", ") || "Heritage, Culture, Local Cuisine"}

Return a strictly valid JSON object with the following schema:
{
  "title": "${destination} Tour",
  "summary": "Brief 1-2 sentence trip overview",
  "estimatedTotalCost": ${budget},
  "days": [
    {
      "dayNumber": 1,
      "title": "Day 1 (City/Area)",
      "date": "Day 1",
      "activities": [
        {
          "id": "act-1",
          "time": "09:00 AM",
          "type": "hotel" | "transport" | "activity" | "meal",
          "title": "Short title",
          "description": "Short description with tips",
          "location": "Specific location or neighborhood",
          "cost": 1500,
          "category": "Luxury" | "Cultural" | "Adventure" | "Nature" | "Dining",
          "duration": "2 Hours"
        }
      ]
    }
  ]
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        },
      });

      const text = response.text;
      if (text) {
        const parsed = JSON.parse(text);
        return res.json({ success: true, data: parsed });
      }
    }

    // Fallback template when AI key is unavailable
    const fallbackItinerary = {
      title: `${destination || "Golden Triangle"} Adventure`,
      summary: `A curated ${days}-day journey across ${destination || "India"}, discovering imperial heritage, royal cuisine, and vibrant markets.`,
      estimatedTotalCost: budget,
      days: Array.from({ length: Math.min(days, 5) }).map((_, idx) => ({
        dayNumber: idx + 1,
        title: `Day ${idx + 1} (${destination || "Delhi & Agra"})`,
        date: `Day ${idx + 1}`,
        activities: [
          {
            id: `act-${idx}-1`,
            time: "09:00 AM",
            type: "hotel",
            title: `Check-in: Heritage Palace Hotel`,
            description: "Luxury stay with traditional Rajasthani courtyard & breakfast.",
            location: `${destination || "City Center"}`,
            cost: Math.round(budget * 0.25 / days),
            category: "Luxury",
            duration: "Overnight",
          },
          {
            id: `act-${idx}-2`,
            time: "11:30 AM",
            type: "transport",
            title: `Private AC Transfer to Historic Fort`,
            description: "Comfortable air-conditioned chauffeur drive.",
            location: `${destination || "Old Town"}`,
            cost: 800,
            category: "Transport",
            duration: "45 mins",
          },
          {
            id: `act-${idx}-3`,
            time: "12:30 PM",
            type: "activity",
            title: `Explore Historic Fortress & Palaces`,
            description: "Guided architectural walk highlighting Mughal and Rajput artisan craftsmanship.",
            location: `${destination || "Monument Ridge"}`,
            cost: 650,
            category: "Cultural",
            duration: "2.5 Hours",
          },
          {
            id: `act-${idx}-4`,
            time: "05:00 PM",
            type: "meal",
            title: `Sunset Rooftop Dining & Local Delicacies`,
            description: "Authentic regional thali dinner with panoramic evening skyline view.",
            location: `Old Haveli Rooftop`,
            cost: 1400,
            category: "Dining",
            duration: "1.5 Hours",
          },
        ],
      })),
    };

    return res.json({ success: true, data: fallbackItinerary });
  } catch (error: any) {
    console.error("Itinerary generation error:", error);
    return res.status(500).json({ error: error.message || "Failed to generate itinerary" });
  }
});

// API: AI Route Optimization & Insights
app.post("/api/itinerary/optimize", async (req, res) => {
  try {
    const { items, destination } = req.body;
    const ai = getGeminiClient();

    if (ai && items?.length) {
      const prompt = `You are a luxury travel concierge for India. Given these schedule items for ${destination || "a trip in India"}:
${JSON.stringify(items, null, 2)}

Provide an optimized chronological order that minimizes travel time, avoids midday heat, and gives 2 smart concierge travel tips.
Return JSON format:
{
  "optimizedOrderIds": ["id1", "id2"],
  "savedTimeMinutes": 35,
  "conciergeTips": [
    "Tip 1 about best time to visit or crowd avoidance",
    "Tip 2 about authentic food or photo spot"
  ]
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        },
      });

      if (response.text) {
        return res.json({ success: true, data: JSON.parse(response.text) });
      }
    }

    return res.json({
      success: true,
      data: {
        savedTimeMinutes: 45,
        conciergeTips: [
          "Visit iconic monuments in early morning (around 07:00 AM) to experience gentle golden hour light and avoid afternoon heat.",
          "Pre-book monument e-tickets via ASI portal to skip ticket counter queues.",
        ],
      },
    });
  } catch (error: any) {
    console.error("Optimization error:", error);
    return res.status(500).json({ error: error.message });
  }
});

// API: AI Travel Assistant Chat
app.post("/api/concierge/chat", async (req, res) => {
  try {
    const { message, history = [] } = req.body;
    const ai = getGeminiClient();

    if (ai) {
      const chat = ai.chats.create({
        model: "gemini-3.7-flash",
        config: {
          systemInstruction: "You are GlobeTrotter AI Concierge, a knowledgeable, sophisticated travel advisor specialized in Incredible India travel, cultural heritage, luxury palaces, backwaters, mountain adventures, regional cuisines, train journeys, and personalized itineraries. Respond helpfully, warmly, and concisely with practical tips.",
        },
      });

      const response = await chat.sendMessage({ message });
      return res.json({ success: true, reply: response.text });
    }

    // Fallback response
    const greetings = [
      `Namaste! I am your GlobeTrotter Concierge. For your journey across India, I recommend exploring the golden dunes of Rajasthan, the serene backwaters of Kerala, or the majestic Himalayas in Ladakh. Would you like me to curate a customized itinerary for any specific region?`,
      `I'd be thrilled to help you plan! The best months for traveling across North India & Kerala are October through March with pleasant sunny days. Let me know your preferred dates, budget, and travel style!`,
    ];
    return res.json({
      success: true,
      reply: greetings[Math.floor(Math.random() * greetings.length)],
    });
  } catch (error: any) {
    console.error("Concierge chat error:", error);
    return res.status(500).json({ error: error.message });
  }
});

// Vite & Static file serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`GlobeTrotter server running on http://localhost:${PORT}`);
  });
}

startServer();
