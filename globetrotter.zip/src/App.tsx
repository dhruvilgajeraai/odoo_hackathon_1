import React, { useState } from "react";
import { ViewType, Destination, Trip } from "./types";
import { INITIAL_TRIPS, FEATURED_DESTINATIONS } from "./data/mockData";
import { Navbar } from "./components/Navbar";
import { BottomNav } from "./components/BottomNav";
import { LandingView } from "./components/LandingView";
import { HomeView } from "./components/HomeView";
import { PlanTripView } from "./components/PlanTripView";
import { ItineraryView } from "./components/ItineraryView";
import { MyTripsView } from "./components/MyTripsView";
import { BudgetView } from "./components/BudgetView";
import { CalendarView } from "./components/CalendarView";
import { ProfileView } from "./components/ProfileView";
import { AdminView } from "./components/AdminView";
import { AuthModal } from "./components/AuthModal";
import { AiConciergeModal } from "./components/AiConciergeModal";

export function App() {
  const [currentView, setCurrentView] = useState<ViewType>("home");
  const [trips, setTrips] = useState<Trip[]>(INITIAL_TRIPS);
  const [currentTrip, setCurrentTrip] = useState<Trip>(INITIAL_TRIPS[0]);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isConciergeOpen, setIsConciergeOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [userEmail, setUserEmail] = useState("aisha.sharma@globetrotter.in");

  const handleNavigate = (view: ViewType) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSelectDestination = (dest: Destination) => {
    // Check if we have an existing trip or generate a quick one
    const matchedTrip = trips.find(t => t.destination.toLowerCase().includes(dest.name.toLowerCase()));
    if (matchedTrip) {
      setCurrentTrip(matchedTrip);
    } else {
      const newTrip: Trip = {
        id: `trip-${dest.id}`,
        title: `${dest.name} Discovery`,
        destination: dest.name,
        dateRange: "Nov 15 - Nov 20, 2023",
        travelersCount: 2,
        travelersText: "2 Adults",
        status: "upcoming",
        totalDays: 5,
        temperature: "28°C",
        imageUrl: dest.imageUrl,
        tags: dest.tags,
        priceCategory: dest.priceLevel === "₹₹₹" ? "₹₹₹ High-End" : "₹₹ Moderate",
        totalBudget: dest.avgCostPerDay * 5,
        paidAmount: Math.round(dest.avgCostPerDay * 5 * 0.6),
        dueAmount: Math.round(dest.avgCostPerDay * 5 * 0.4),
        transportMode: "Flight",
        days: [
          {
            dayNumber: 1,
            title: `Day 1 (${dest.name})`,
            date: "Nov 15",
            activities: [
              {
                id: `act-${dest.id}-1`,
                time: "10:00 AM",
                type: "hotel",
                title: `Check-in: Grand ${dest.name} Heritage Retreat`,
                description: `Signature luxury palace stay with traditional welcome amenities.`,
                location: `${dest.name} Center`,
                cost: 12000,
                category: "Luxury",
                duration: "Overnight",
              },
              {
                id: `act-${dest.id}-2`,
                time: "03:00 PM",
                type: "activity",
                title: `Guided Exploration: ${dest.popularFor[0] || "City Center"}`,
                description: `Private guided walkthrough of iconic architecture and cultural points of interest.`,
                location: `${dest.name}`,
                cost: 850,
                category: "Cultural",
                duration: "2.5 Hours",
              },
            ],
          },
        ],
      };
      setTrips(prev => [newTrip, ...prev]);
      setCurrentTrip(newTrip);
    }
    handleNavigate("itinerary");
  };

  const handleTripGenerated = (newTrip: Trip) => {
    setTrips(prev => [newTrip, ...prev]);
    setCurrentTrip(newTrip);
  };

  const handleUpdateTrip = (updated: Trip) => {
    setCurrentTrip(updated);
    setTrips(prev => prev.map(t => t.id === updated.id ? updated : t));
  };

  const handleLoginSuccess = (email: string) => {
    setUserEmail(email);
    setIsLoggedIn(true);
  };

  return (
    <div className="min-h-screen bg-[#f7f9fb] text-[#191c1e] flex flex-col font-sans selection:bg-[#2563eb]/20 selection:text-[#004ac6] pb-20 md:pb-8">
      {/* Top Navbar */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenConcierge={() => setIsConciergeOpen(true)}
        isLoggedIn={isLoggedIn}
        userEmail={userEmail}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {currentView === "landing" && (
          <LandingView
            onNavigate={handleNavigate}
            onOpenConcierge={() => setIsConciergeOpen(true)}
          />
        )}

        {currentView === "home" && (
          <HomeView
            onNavigate={handleNavigate}
            onSelectDestination={handleSelectDestination}
            onOpenConcierge={() => setIsConciergeOpen(true)}
          />
        )}

        {currentView === "plan" && (
          <PlanTripView
            onNavigate={handleNavigate}
            onTripGenerated={handleTripGenerated}
          />
        )}

        {currentView === "itinerary" && (
          <ItineraryView
            currentTrip={currentTrip}
            onNavigate={handleNavigate}
            onUpdateTrip={handleUpdateTrip}
          />
        )}

        {currentView === "trips" && (
          <MyTripsView
            trips={trips}
            onNavigate={handleNavigate}
            onSelectTrip={(t) => {
              setCurrentTrip(t);
              handleNavigate("itinerary");
            }}
          />
        )}

        {currentView === "budget" && (
          <BudgetView
            currentTrip={currentTrip}
            onNavigate={handleNavigate}
          />
        )}

        {currentView === "calendar" && (
          <CalendarView
            onNavigate={handleNavigate}
          />
        )}

        {currentView === "profile" && (
          <ProfileView
            onNavigate={handleNavigate}
          />
        )}

        {currentView === "admin" && (
          <AdminView
            onNavigate={handleNavigate}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav
        currentView={currentView}
        onNavigate={handleNavigate}
      />

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* AI Concierge Chatbot Drawer */}
      <AiConciergeModal
        isOpen={isConciergeOpen}
        onClose={() => setIsConciergeOpen(false)}
        onPlanTripShortcut={(dest) => {
          setIsConciergeOpen(false);
          handleNavigate("plan");
        }}
      />
    </div>
  );
}

export default App;
