export type ViewType =
  | "landing"
  | "home"
  | "plan"
  | "itinerary"
  | "trips"
  | "budget"
  | "calendar"
  | "profile"
  | "admin";

export type CategoryType = "Cultural" | "Adventure" | "₹₹ High-End" | "Nature" | "Heritage" | "Relaxation" | "Leisure" | "Beaches" | "Dining";

export interface Destination {
  id: string;
  name: string;
  state: string;
  tagline: string;
  description: string;
  imageUrl: string;
  tags: CategoryType[];
  rating: number;
  priceLevel: "₹" | "₹₹" | "₹₹₹";
  avgCostPerDay: number;
  popularFor: string[];
  isFavorite?: boolean;
}

export interface ActivityItem {
  id: string;
  time: string;
  type: "hotel" | "transport" | "activity" | "meal";
  title: string;
  description: string;
  location: string;
  cost: number;
  category: CategoryType | "Transport" | "Luxury";
  duration: string;
  imageUrl?: string;
  status?: "confirmed" | "pending" | "paid";
}

export interface DayItinerary {
  dayNumber: number;
  title: string;
  date: string;
  activities: ActivityItem[];
}

export interface Trip {
  id: string;
  title: string;
  destination: string;
  dateRange: string;
  travelersCount: number;
  travelersText: string;
  status: "ongoing" | "upcoming" | "completed";
  currentDay?: number;
  totalDays: number;
  temperature?: string;
  weatherCondition?: string;
  imageUrl: string;
  tags: CategoryType[];
  priceCategory: "₹ Budget" | "₹₹ Moderate" | "₹₹₹ High-End";
  totalBudget: number;
  paidAmount: number;
  dueAmount: number;
  days: DayItinerary[];
  transportMode: "Flight" | "Train" | "Car";
  isFavorite?: boolean;
}

export interface WeatherInfo {
  city: string;
  temp: number;
  condition: "Sunny" | "Light Rain" | "Cloudy" | "Partly Cloudy";
  icon: string;
}

export interface CalendarEvent {
  id: string;
  date: number;
  month: string;
  year: number;
  title: string;
  type: "trip" | "flight" | "holiday" | "reminder";
  tripId?: string;
  badgeText?: string;
  color?: string;
  time?: string;
  details?: string;
}

export interface AchievementBadge {
  id: string;
  title: string;
  category: string;
  iconName: string;
  isUnlocked: boolean;
  colorClass: string;
}

export interface WishlistItem {
  id: string;
  title: string;
  subtitle: string;
  savedTime: string;
  imageUrl: string;
}

export interface PastJourney {
  id: string;
  title: string;
  dates: string;
  duration: string;
}

export interface StatePerformance {
  rank: number;
  name: string;
  revenue: string;
  growth: string;
  isPositive: boolean;
}

export interface AiInsight {
  id: string;
  type: "trend" | "pricing" | "opportunity";
  title: string;
  description: string;
  actionText?: string;
}
