import React, { useState } from "react";
import { ViewType } from "../types";
import { 
  User, 
  MapPin, 
  Share2, 
  Edit3, 
  Mountain, 
  Utensils, 
  Landmark, 
  Ship, 
  Lock, 
  CheckCircle2, 
  Heart, 
  Clock, 
  Compass, 
  Sparkles,
  ChevronRight
} from "lucide-react";
import { PROFILE_STATS, ACHIEVEMENTS, WISHLIST_ITEMS, PAST_JOURNEYS } from "../data/mockData";

interface ProfileViewProps {
  onNavigate: (view: ViewType) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onNavigate }) => {
  const [copied, setCopied] = useState(false);
  const [selectedState, setSelectedState] = useState<string | null>("Rajasthan");

  const handleShare = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const indianStates = [
    { name: "Rajasthan", visits: 6, status: "explored", highlights: "Jaipur, Udaipur, Jodhpur" },
    { name: "Maharashtra", visits: 12, status: "explored", highlights: "Mumbai, Pune, Ajanta" },
    { name: "Kerala", visits: 4, status: "explored", highlights: "Alleppey, Munnar, Kochi" },
    { name: "Himachal Pradesh", visits: 3, status: "explored", highlights: "Manali, Shimla, Dharamshala" },
    { name: "Uttar Pradesh", visits: 5, status: "explored", highlights: "Agra, Varanasi, Lucknow" },
    { name: "Goa", visits: 8, status: "explored", highlights: "North Goa, South Goa, Panaji" },
    { name: "Ladakh", visits: 2, status: "explored", highlights: "Leh, Pangong, Nubra" },
    { name: "Karnataka", visits: 4, status: "explored", highlights: "Bengaluru, Hampi, Coorg" },
    { name: "Tamil Nadu", visits: 2, status: "explored", highlights: "Chennai, Madurai" },
    { name: "West Bengal", visits: 1, status: "explored", highlights: "Kolkata, Darjeeling" },
    { name: "Uttarakhand", visits: 3, status: "explored", highlights: "Rishikesh, Mussoorie" },
    { name: "Sikkim", visits: 1, status: "explored", highlights: "Gangtok, Pelling" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-8 space-y-8">
      {/* Profile Header Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-black/5 shadow-xs flex flex-col sm:flex-row items-center sm:items-start justify-between gap-6">
        <div className="flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
          <div className="relative">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden ring-4 ring-[#004ac6]/20 shadow-md">
              <img 
                src={PROFILE_STATS.avatarUrl} 
                alt={PROFILE_STATS.name} 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-[#006c49] text-white flex items-center justify-center text-xs ring-2 ring-white shadow-xs">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>

          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#dbe1ff] text-[#004ac6] text-[11px] font-bold">
              <span>Verified Explorer</span>
              <CheckCircle2 className="w-3 h-3 text-[#004ac6]" />
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#191c1e]">
              {PROFILE_STATS.name}
            </h1>
            <p className="text-xs sm:text-sm text-[#737686] flex items-center justify-center sm:justify-start gap-1">
              <MapPin className="w-3.5 h-3.5 text-[#004ac6]" />
              <span>{PROFILE_STATS.location} • Heritage & Slow Travel Enthusiast</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleShare}
            id="share-profile-btn"
            className="px-4 py-2 rounded-xl border border-black/10 bg-white hover:bg-[#f2f4f6] text-xs font-semibold text-[#191c1e] transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>{copied ? "Link Copied!" : "Share Profile"}</span>
          </button>

          <button
            onClick={() => onNavigate("plan")}
            id="profile-plan-cta-btn"
            className="px-4 py-2 rounded-xl bg-[#004ac6] text-white hover:bg-[#2563eb] text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Plan Next Trip</span>
          </button>
        </div>
      </div>

      {/* Stats Bento Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-black/5 p-5 shadow-xs text-center space-y-1">
          <div className="text-2xl sm:text-3xl font-extrabold text-[#004ac6]">
            {PROFILE_STATS.trips}
          </div>
          <div className="text-xs font-bold text-[#737686] uppercase tracking-wider">
            Trips Logged
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-black/5 p-5 shadow-xs text-center space-y-1">
          <div className="text-2xl sm:text-3xl font-extrabold text-[#006c49]">
            {PROFILE_STATS.states} / 28
          </div>
          <div className="text-xs font-bold text-[#737686] uppercase tracking-wider">
            States Explored
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-black/5 p-5 shadow-xs text-center space-y-1">
          <div className="text-2xl sm:text-3xl font-extrabold text-[#943700]">
            {PROFILE_STATS.cities}
          </div>
          <div className="text-xs font-bold text-[#737686] uppercase tracking-wider">
            Cities Visited
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-black/5 p-5 shadow-xs text-center space-y-1">
          <div className="text-2xl sm:text-3xl font-extrabold text-[#191c1e]">
            {PROFILE_STATS.kmTraveled}
          </div>
          <div className="text-xs font-bold text-[#737686] uppercase tracking-wider">
            Kilometers Traveled
          </div>
        </div>
      </div>

      {/* India Exploration Heatmap & Visited States Interactive Map */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        {/* Heatmap & State Explorer */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 border border-black/5 shadow-xs space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-bold text-[#191c1e]">
                India Exploration Heatmap
              </h2>
              <p className="text-xs text-[#737686]">64% of Indian states and union territories visited</p>
            </div>
            <span className="text-xs font-bold text-[#006c49] bg-[#6ffbbe]/20 px-3 py-1 rounded-full">
              Level 4 Explorer
            </span>
          </div>

          {/* Interactive State Chips Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 pt-2">
            {indianStates.map((st) => {
              const isSelected = selectedState === st.name;
              return (
                <button
                  key={st.name}
                  onClick={() => setSelectedState(st.name)}
                  className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                    isSelected
                      ? "border-[#004ac6] bg-[#dbe1ff]/40 shadow-xs"
                      : "border-black/5 hover:border-black/15 bg-[#f7f9fb]"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className="text-xs font-bold text-[#191c1e]">{st.name}</span>
                    <span className="text-[10px] font-semibold text-[#004ac6]">{st.visits}x</span>
                  </div>
                  <div className="text-[10px] text-[#737686] truncate mt-1">
                    {st.highlights}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Selected State Highlight Banner */}
          {selectedState && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-[#dbe1ff] to-[#6ffbbe]/30 border border-[#004ac6]/20 flex flex-col sm:flex-row justify-between items-center gap-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#004ac6]">Selected Region</span>
                <h4 className="text-sm font-bold text-[#00174b]">{selectedState}</h4>
                <p className="text-xs text-[#00174b]/80">
                  Multiple expeditions recorded. Recommended next: Remote fort stays and craft trails.
                </p>
              </div>
              <button
                onClick={() => onNavigate("plan")}
                className="px-3.5 py-1.5 rounded-xl bg-[#004ac6] text-white text-xs font-bold hover:bg-[#2563eb] shrink-0"
              >
                Plan Next in {selectedState}
              </button>
            </div>
          )}
        </div>

        {/* Badges & Achievements */}
        <div className="bg-white rounded-3xl p-6 border border-black/5 shadow-xs space-y-4">
          <h2 className="text-lg font-bold text-[#191c1e]">
            Badges & Achievements
          </h2>

          <div className="space-y-3">
            {ACHIEVEMENTS.map((ach) => {
              let IconComp = Mountain;
              if (ach.iconName === "utensils") IconComp = Utensils;
              if (ach.iconName === "landmark") IconComp = Landmark;
              if (ach.iconName === "ship") IconComp = Ship;

              return (
                <div
                  key={ach.id}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between transition-all ${
                    ach.isUnlocked
                      ? "border-black/5 bg-[#f7f9fb]"
                      : "border-black/5 bg-black/5 opacity-60"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${ach.colorClass} shadow-xs`}>
                      <IconComp className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-[#191c1e]">
                        {ach.title}
                      </h4>
                      <span className="text-[10px] text-[#737686]">
                        {ach.category} Category
                      </span>
                    </div>
                  </div>

                  {ach.isUnlocked ? (
                    <span className="text-[10px] font-bold text-[#006c49] bg-[#6ffbbe]/30 px-2 py-0.5 rounded-full flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      Unlocked
                    </span>
                  ) : (
                    <span className="text-[10px] font-bold text-[#737686] flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      Locked
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Wishlist & Past Journeys */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
        {/* Wishlist */}
        <div className="bg-white rounded-3xl p-6 border border-black/5 shadow-xs space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-base font-bold text-[#191c1e] flex items-center gap-2">
              <Heart className="w-4 h-4 text-[#ba1a1a] fill-[#ba1a1a]" />
              <span>Saved Wishlist</span>
            </h3>
            <button 
              onClick={() => onNavigate("home")} 
              className="text-xs font-semibold text-[#004ac6] hover:underline"
            >
              Explore More
            </button>
          </div>

          <div className="space-y-3">
            {WISHLIST_ITEMS.map((item) => (
              <div
                key={item.id}
                onClick={() => onNavigate("plan")}
                className="flex items-center gap-3.5 p-2.5 rounded-2xl hover:bg-[#f7f9fb] transition-colors cursor-pointer group"
              >
                <div className="w-14 h-14 rounded-xl overflow-hidden bg-[#eceef0] shrink-0">
                  <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                </div>
                <div className="flex-1">
                  <h4 className="text-xs font-bold text-[#191c1e] group-hover:text-[#004ac6] transition-colors">
                    {item.title}
                  </h4>
                  <span className="text-[11px] text-[#737686]">{item.subtitle}</span>
                </div>
                <ChevronRight className="w-4 h-4 text-[#737686] group-hover:translate-x-1 transition-transform" />
              </div>
            ))}
          </div>
        </div>

        {/* Past Journeys History */}
        <div className="bg-white rounded-3xl p-6 border border-black/5 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-[#191c1e] flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#004ac6]" />
            <span>Past Travel Log</span>
          </h3>

          <div className="space-y-3">
            {PAST_JOURNEYS.map((past) => (
              <div
                key={past.id}
                className="p-3 rounded-2xl bg-[#f7f9fb] flex items-center justify-between"
              >
                <div>
                  <h4 className="text-xs font-bold text-[#191c1e]">{past.title}</h4>
                  <span className="text-[10px] text-[#737686]">{past.dates}</span>
                </div>
                <span className="text-xs font-semibold text-[#004ac6] bg-[#dbe1ff] px-2.5 py-0.5 rounded-full">
                  {past.duration}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
