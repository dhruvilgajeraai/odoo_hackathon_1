import React, { useState } from "react";
import { 
  X, 
  MapPin, 
  Mail, 
  Lock, 
  Eye, 
  EyeOff, 
  Fingerprint, 
  ArrowRight,
  Sparkles
} from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (email: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
}) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("aisha.sharma@globetrotter.in");
  const [password, setPassword] = useState("••••••••••••");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLoginSuccess(email);
      onClose();
    }, 600);
  };

  const handleBiometric = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLoginSuccess("aisha.sharma@globetrotter.in");
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-md bg-white/90 backdrop-blur-2xl rounded-3xl p-6 sm:p-8 shadow-2xl border border-white z-10 space-y-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          id="auth-modal-close-btn"
          className="absolute top-5 right-5 p-2 rounded-full text-[#737686] hover:bg-black/5 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#004ac6] to-[#006c49] text-white shadow-md mb-1">
            <MapPin className="w-6 h-6 fill-white" />
          </div>
          <h2 className="text-2xl font-extrabold text-[#191c1e] tracking-tight">
            {isSignUp ? "Join GlobeTrotter" : "Welcome Back"}
          </h2>
          <p className="text-xs text-[#737686]">
            {isSignUp
              ? "Create your bespoke Indian travel passport"
              : "Sign in to access your curated Indian itineraries & perks"}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-[#434655] uppercase tracking-wider block mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#737686]" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-black/10 bg-white/80 focus:bg-white focus:ring-2 focus:ring-[#004ac6] outline-none text-xs font-medium text-[#191c1e]"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-xs font-bold text-[#434655] uppercase tracking-wider">
                Password
              </label>
              {!isSignUp && (
                <button
                  type="button"
                  onClick={() => alert("Password reset link sent to " + email)}
                  className="text-[11px] font-semibold text-[#004ac6] hover:underline"
                >
                  Forgot?
                </button>
              )}
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#737686]" />
              <input
                type={showPassword ? "text" : "password"}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-10 py-3 rounded-xl border border-black/10 bg-white/80 focus:bg-white focus:ring-2 focus:ring-[#004ac6] outline-none text-xs font-medium text-[#191c1e]"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#737686] hover:text-[#191c1e]"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            id="auth-submit-btn"
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#004ac6] to-[#006c49] text-white text-xs font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
          >
            <span>{isSignUp ? "Create Explorer Account" : "Sign In with Email"}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Divider */}
        <div className="relative flex items-center justify-center">
          <div className="w-full border-t border-black/10" />
          <span className="bg-white/90 px-3 text-[10px] uppercase font-bold text-[#737686] absolute">
            or instant authentication
          </span>
        </div>

        {/* Social / Biometric */}
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={handleBiometric}
            className="py-2.5 px-3 rounded-xl border border-black/10 bg-white hover:bg-[#f7f9fb] transition-colors flex items-center justify-center gap-2 text-xs font-semibold text-[#191c1e]"
          >
            <Fingerprint className="w-4 h-4 text-[#004ac6]" />
            <span>Biometric</span>
          </button>

          <button
            type="button"
            onClick={handleBiometric}
            className="py-2.5 px-3 rounded-xl border border-black/10 bg-white hover:bg-[#f7f9fb] transition-colors flex items-center justify-center gap-2 text-xs font-semibold text-[#191c1e]"
          >
            <Sparkles className="w-4 h-4 text-[#006c49]" />
            <span>Google Account</span>
          </button>
        </div>

        {/* Switch mode */}
        <div className="text-center text-xs text-[#737686]">
          {isSignUp ? "Already have an account? " : "New to GlobeTrotter? "}
          <button
            type="button"
            onClick={() => setIsSignUp(!isSignUp)}
            className="font-bold text-[#004ac6] hover:underline"
          >
            {isSignUp ? "Sign In" : "Create Account"}
          </button>
        </div>
      </div>
    </div>
  );
};
