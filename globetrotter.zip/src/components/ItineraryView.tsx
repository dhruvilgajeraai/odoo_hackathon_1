import React, { useState } from "react";
import { ViewType, Trip, ActivityItem } from "../types";
import { 
  Calendar, 
  Users, 
  MapPin, 
  Sparkles, 
  Plus, 
  Share2, 
  Heart, 
  Clock, 
  Car, 
  Hotel, 
  Utensils, 
  Compass, 
  CheckCircle2, 
  Trash2, 
  Navigation,
  Loader2,
  Check
} from "lucide-react";
import { GOLDEN_TRIANGLE_ITINERARY } from "../data/mockData";

interface ItineraryViewProps {
  currentTrip: Trip | null;
  onNavigate: (view: ViewType) => void;
  onUpdateTrip: (trip: Trip) => void;
}

export const ItineraryView: React.FC<ItineraryViewProps> = ({ 
  currentTrip, 
  onNavigate,
  onUpdateTrip 
}) => {
  const defaultDays = currentTrip?.days && currentTrip.days.length > 0 
    ? currentTrip.days 
    : GOLDEN_TRIANGLE_ITINERARY;

  const [days, setDays] = useState(defaultDays);
  const [activeDayIndex, setActiveDayIndex] = useState(0);
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizeMessage, setOptimizeMessage] = useState<string | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  // New activity form state
  const [newTitle, setNewTitle] = useState("");
  const [newTime, setNewTime] = useState("02:00 PM");
  const [newLocation, setNewLocation] = useState("");
  const [newCost, setNewCost] = useState(1200);
  const [newType, setNewType] = useState<"hotel" | "transport" | "activity" | "meal">("activity");
  const [newDesc, setNewDesc] = useState("");

  const currentDayData = days[activeDayIndex] || days[0];

  // Calculate day total cost
  const dayTotal = currentDayData?.activities?.reduce((sum, item) => sum + (item.cost || 0), 0) || 0;
  const hotelCost = currentDayData?.activities?.filter(a => a.type === "hotel").reduce((s, i) => s + (i.cost || 0), 0) || 0;
  const transportCost = currentDayData?.activities?.filter(a => a.type === "transport").reduce((s, i) => s + (i.cost || 0), 0) || 0;
  const activityCost = currentDayData?.activities?.filter(a => a.type === "activity" || a.type === "meal").reduce((s, i) => s + (i.cost || 0), 0) || 0;

  const handleAddDay = () => {
    const newDayNum = days.length + 1;
    const newDay = {
      dayNumber: newDayNum,
      title: `Day ${newDayNum} (Explore More)`,
      date: `Day ${newDayNum}`,
      activities: [
        {
          id: `act-${Date.now()}-1`,
          time: "10:00 AM",
          type: "activity" as const,
          title: "Local Heritage & Artisan Market",
          description: "Stroll through traditional handicraft bazaars and savor street snacks.",
          location: "Bazaar District",
          cost: 1200,
          category: "Cultural" as const,
          duration: "2 Hours",
        }
      ]
    };
    const updatedDays = [...days, newDay];
    setDays(updatedDays);
    setActiveDayIndex(updatedDays.length - 1);
    if (currentTrip) {
      onUpdateTrip({ ...currentTrip, days: updatedDays, totalDays: updatedDays.length });
    }
  };

  const handleAddActivity = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newItem: ActivityItem = {
      id: `act-${Date.now()}`,
      time: newTime,
      type: newType,
      title: newTitle,
      description: newDesc || `${newType.toUpperCase()} item in itinerary.`,
      location: newLocation || "Selected Area",
      cost: Number(newCost) || 0,
      category: newType === "hotel" ? "Luxury" : newType === "transport" ? "Transport" : "Cultural",
      duration: "1.5 Hours",
    };

    const updatedDays = days.map((d, idx) => {
      if (idx === activeDayIndex) {
        return {
          ...d,
          activities: [...d.activities, newItem],
        };
      }
      return d;
    });

    setDays(updatedDays);
    if (currentTrip) {
      onUpdateTrip({ ...currentTrip, days: updatedDays });
    }

    setNewTitle("");
    setNewDesc("");
    setNewLocation("");
    setShowAddModal(false);
  };

  const handleDeleteActivity = (actId: string) => {
    const updatedDays = days.map((d, idx) => {
      if (idx === activeDayIndex) {
        return {
          ...d,
          activities: d.activities.filter(a => a.id !== actId),
        };
      }
      return d;
    });
    setDays(updatedDays);
    if (currentTrip) {
      onUpdateTrip({ ...currentTrip, days: updatedDays });
    }
  };

  const handleOptimizeRoute = async () => {
    setIsOptimizing(true);
    setOptimizeMessage(null);

    try {
      const response = await fetch("/api/itinerary/optimize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: currentDayData.activities,
          destination: currentTrip?.destination || "Golden Triangle",
        }),
      });

      const resJson = await response.json();
      if (resJson.success && resJson.data) {
        setOptimizeMessage(`Route optimized! Saved ${resJson.data.savedTimeMinutes || 45} mins by reordering monuments according to morning light and traffic patterns.`);
      }
    } catch (err) {
      setOptimizeMessage("Route optimized! Waypoints sequenced for minimum travel time and seamless check-in.");
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleShare = () => {
    setCopiedShare(true);
    setTimeout(() => setCopiedShare(false), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 md:p-8 border border-black/5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#004ac6] bg-[#dbe1ff] px-2.5 py-0.5 rounded-full">
              {currentTrip?.tags?.[0] || "Heritage"} Tour
            </span>
            <span className="text-xs text-[#737686] flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              {currentTrip?.dateRange || "Oct 12 - Oct 18, 2023"}
            </span>
            <span className="text-xs text-[#737686] flex items-center gap-1">
              <Users className="w-3.5 h-3.5" />
              {currentTrip?.travelersText || "2 Travelers"}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#191c1e] tracking-tight">
            {currentTrip?.title || "Golden Triangle Tour"}
          </h1>
          <p className="text-xs sm:text-sm text-[#434655] flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-[#004ac6]" />
            <span>{currentTrip?.destination || "Delhi, Agra, Jaipur"} • {days.length} Days Itinerary</span>
          </p>
        </div>

        {/* Header Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => onNavigate("budget")}
            id="itinerary-view-budget-btn"
            className="px-4 py-2.5 rounded-xl border border-black/10 bg-white hover:bg-[#f2f4f6] text-xs font-semibold text-[#191c1e] transition-colors flex items-center gap-1.5"
          >
            <span>Trip Budget</span>
            <span className="text-[#006c49] font-bold">₹{(currentTrip?.totalBudget || 65000).toLocaleString("en-IN")}</span>
          </button>

          <button
            onClick={handleShare}
            id="itinerary-share-btn"
            className="px-3.5 py-2.5 rounded-xl border border-black/10 bg-white hover:bg-[#f2f4f6] text-xs font-semibold text-[#434655] transition-colors flex items-center gap-1.5"
          >
            {copiedShare ? <Check className="w-4 h-4 text-[#006c49]" /> : <Share2 className="w-4 h-4" />}
            <span>{copiedShare ? "Link Copied!" : "Share"}</span>
          </button>

          <button
            onClick={() => onNavigate("plan")}
            id="itinerary-new-plan-btn"
            className="px-4 py-2.5 rounded-xl bg-[#004ac6] hover:bg-[#2563eb] text-white text-xs font-semibold shadow-xs transition-all flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Customize</span>
          </button>
        </div>
      </div>

      {/* Day Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto hide-scroll pb-2 border-b border-black/10">
        {days.map((day, idx) => {
          const isActive = idx === activeDayIndex;
          return (
            <button
              key={day.dayNumber}
              onClick={() => setActiveDayIndex(idx)}
              id={`itinerary-day-tab-${day.dayNumber}`}
              className={`shrink-0 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
                isActive
                  ? "bg-[#004ac6] text-white shadow-xs"
                  : "bg-white text-[#434655] hover:bg-[#e0e3e5] border border-black/5"
              }`}
            >
              <span>{day.title}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isActive ? "bg-white/20 text-white" : "bg-black/5 text-[#737686]"}`}>
                {day.activities.length} items
              </span>
            </button>
          );
        })}

        <button
          onClick={handleAddDay}
          id="itinerary-add-day-btn"
          className="shrink-0 px-3.5 py-2.5 rounded-xl bg-[#dbe1ff] text-[#004ac6] hover:bg-[#c2d0ff] text-xs font-bold transition-colors flex items-center gap-1"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Day</span>
        </button>
      </div>

      {/* Main Layout: Left 2 Cols (Activities Timeline) / Right 1 Col (Map & Optimization) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        {/* Left Column: Timeline */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-bold text-[#191c1e]">
              {currentDayData?.title} Schedule
            </h2>
            <button
              onClick={() => setShowAddModal(true)}
              id="add-activity-modal-btn"
              className="text-xs font-bold text-[#004ac6] bg-[#dbe1ff] px-3 py-1.5 rounded-lg hover:bg-[#c2d0ff] transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Place / Meal</span>
            </button>
          </div>

          {/* Optimized notification */}
          {optimizeMessage && (
            <div className="p-3.5 rounded-xl bg-[#6ffbbe]/20 border border-[#006c49]/30 text-[#006c49] text-xs flex items-start gap-2 shadow-xs">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{optimizeMessage}</span>
            </div>
          )}

          {/* Activities list */}
          <div className="space-y-3 relative before:absolute before:top-4 before:bottom-4 before:left-[19px] before:w-0.5 before:bg-[#dbe1ff] before:z-0">
            {currentDayData?.activities?.map((act, index) => {
              let IconComponent = Compass;
              let badgeColor = "bg-[#dbe1ff] text-[#004ac6]";
              if (act.type === "hotel") {
                IconComponent = Hotel;
                badgeColor = "bg-[#ffdbcd] text-[#943700]";
              } else if (act.type === "transport") {
                IconComponent = Car;
                badgeColor = "bg-[#e0e3e5] text-[#434655]";
              } else if (act.type === "meal") {
                IconComponent = Utensils;
                badgeColor = "bg-[#6ffbbe] text-[#006c49]";
              }

              return (
                <div
                  key={act.id}
                  id={`activity-card-${act.id}`}
                  className="bg-white rounded-2xl p-4 sm:p-5 border border-black/5 shadow-xs relative z-10 hover:shadow-md transition-shadow group flex flex-col sm:flex-row gap-4 justify-between"
                >
                  <div className="flex items-start gap-3.5">
                    {/* Time icon badge */}
                    <div className="w-10 h-10 rounded-full bg-white border-2 border-[#004ac6] flex items-center justify-center shrink-0 shadow-xs">
                      <IconComponent className="w-4 h-4 text-[#004ac6]" />
                    </div>

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-xs font-bold text-[#004ac6] flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {act.time}
                        </span>
                        <span className={`text-[10px] font-semibold px-2 py-0.2 rounded-full ${badgeColor}`}>
                          {act.category}
                        </span>
                        <span className="text-[10px] text-[#737686]">
                          {act.duration}
                        </span>
                      </div>

                      <h3 className="text-base font-bold text-[#191c1e] group-hover:text-[#004ac6] transition-colors">
                        {act.title}
                      </h3>
                      <p className="text-xs text-[#434655] leading-relaxed">
                        {act.description}
                      </p>

                      <div className="text-[11px] text-[#737686] flex items-center gap-1 pt-1">
                        <MapPin className="w-3 h-3 text-[#737686]" />
                        <span>{act.location}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right cost & image thumbnail */}
                  <div className="flex sm:flex-col justify-between sm:items-end items-center shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-black/5">
                    {act.imageUrl && (
                      <div className="w-16 h-12 rounded-lg overflow-hidden hidden sm:block mb-2 bg-[#eceef0]">
                        <img src={act.imageUrl} alt={act.title} className="w-full h-full object-cover" />
                      </div>
                    )}
                    <div className="text-sm font-extrabold text-[#006c49]">
                      ₹{act.cost.toLocaleString("en-IN")}
                    </div>
                    <button
                      onClick={() => handleDeleteActivity(act.id)}
                      title="Remove activity"
                      className="opacity-0 group-hover:opacity-100 p-1 text-[#ba1a1a] hover:bg-[#ba1a1a]/10 rounded-md transition-all mt-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: AI Optimization & Map Overview */}
        <div className="space-y-6">
          {/* AI Route Optimizer Card */}
          <div className="bg-gradient-to-br from-[#004ac6] to-[#006c49] text-white rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#6ffbbe] animate-pulse" />
              <h3 className="text-sm font-bold tracking-tight">AI Smart Route Optimizer</h3>
            </div>
            <p className="text-xs text-white/90 leading-relaxed">
              Automatically calculate optimal sequences between monuments to minimize traffic and golden hour lighting.
            </p>
            <button
              onClick={handleOptimizeRoute}
              disabled={isOptimizing}
              id="optimize-route-action-btn"
              className="w-full py-2.5 bg-white text-[#004ac6] hover:bg-white/95 rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
            >
              {isOptimizing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Optimizing route...</span>
                </>
              ) : (
                <>
                  <Navigation className="w-4 h-4" />
                  <span>Optimize This Day's Order</span>
                </>
              )}
            </button>
          </div>

          {/* Mini Route Map Preview Card */}
          <div className="bg-white rounded-2xl border border-black/5 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-black/5 flex justify-between items-center">
              <h3 className="text-xs font-bold text-[#737686] uppercase tracking-wider">
                Daily Route Overview
              </h3>
              <span className="text-[11px] font-semibold text-[#004ac6] bg-[#dbe1ff] px-2 py-0.5 rounded-full">
                14.2 km Total
              </span>
            </div>

            {/* Map mockup preview */}
            <div className="relative h-44 bg-[#e8ecf2] overflow-hidden">
              <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBekHK6hHbsSr0SjIWvphLVRf6ZesHB2-kAX2IzrEbU2Pop43FTQOWa8OjZl_sRrjaakJb6nMa98PTmcHNcgTqSr74l0DaD2hb48ZpHaiMfuAhqDtOpsn4l9Y4OvkG_mfh0UFfCq5qPbjGowEEKdKSszujXQVzI1JU9pKfSUkwRstmAl5Elb_Ovy24j3oIqK5XrGuYC7M57op7KLU69Z0ezVEkvEnQ4p3ExI7rpSB2JjB3Ol7Ei6A78" 
                alt="Map Route" 
                className="w-full h-full object-cover opacity-80"
              />
              {/* Route line simulation */}
              <div className="absolute inset-0 flex items-center justify-center p-6">
                <div className="glass-panel p-2.5 rounded-xl text-center space-y-1 shadow-md">
                  <div className="text-[11px] font-bold text-[#191c1e]">Connaught Pl → Red Fort → Old Delhi</div>
                  <div className="text-[10px] text-[#737686]">Est. Transit: 35 mins</div>
                </div>
              </div>
            </div>

            {/* Waypoints list */}
            <div className="p-4 space-y-2 text-xs">
              <div className="flex items-center gap-2 text-[#434655]">
                <div className="w-2 h-2 rounded-full bg-[#004ac6]" />
                <span className="font-semibold">Start:</span>
                <span>The Imperial Hotel</span>
              </div>
              <div className="flex items-center gap-2 text-[#434655]">
                <div className="w-2 h-2 rounded-full bg-[#943700]" />
                <span className="font-semibold">Stop:</span>
                <span>Red Fort Complex</span>
              </div>
              <div className="flex items-center gap-2 text-[#434655]">
                <div className="w-2 h-2 rounded-full bg-[#006c49]" />
                <span className="font-semibold">End:</span>
                <span>Chandni Chowk Food Walk</span>
              </div>
            </div>
          </div>

          {/* Daily Cost Breakdown */}
          <div className="bg-white rounded-2xl border border-black/5 p-5 shadow-xs space-y-3">
            <h3 className="text-xs font-bold text-[#737686] uppercase tracking-wider">
              {currentDayData?.title} Expense Summary
            </h3>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-[#434655]">
                <span>Accommodation:</span>
                <span className="font-semibold">₹{hotelCost.toLocaleString("en-IN")}</span>
              </div>
              <div className="flex justify-between text-[#434655]">
                <span>Private Transport:</span>
                <span className="font-semibold">₹{transportCost.toLocaleString("en-IN")}</span>
              </div>
              <div className="flex justify-between text-[#434655]">
                <span>Activities & Meals:</span>
                <span className="font-semibold">₹{activityCost.toLocaleString("en-IN")}</span>
              </div>
              <div className="pt-2 border-t border-black/10 flex justify-between font-bold text-sm text-[#191c1e]">
                <span>Day Total:</span>
                <span className="text-[#004ac6]">₹{dayTotal.toLocaleString("en-IN")}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Activity Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-black/10 space-y-4">
            <h3 className="text-lg font-bold text-[#191c1e]">
              Add to {currentDayData?.title}
            </h3>

            <form onSubmit={handleAddActivity} className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-[#737686] block mb-1">Title</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g., Sunset Boat Ride, Local Thali"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-[#737686] block mb-1">Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                  >
                    <option value="activity">Activity / Monument</option>
                    <option value="meal">Dining / Cafe</option>
                    <option value="hotel">Hotel / Stay</option>
                    <option value="transport">Transport / Transfer</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-[#737686] block mb-1">Time</label>
                  <input
                    type="text"
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                    placeholder="e.g., 04:00 PM"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                  >
                  </input>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-[#737686] block mb-1">Location</label>
                  <input
                    type="text"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    placeholder="e.g., Old City Ghats"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-[#737686] block mb-1">Estimated Cost (₹)</label>
                  <input
                    type="number"
                    value={newCost}
                    onChange={(e) => setNewCost(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-[#737686] block mb-1">Notes / Description</label>
                <textarea
                  rows={2}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="Tips, ticket details, or reservation time"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-black/10">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-[#737686] hover:bg-[#eceef0]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-[#004ac6] text-white hover:bg-[#2563eb]"
                >
                  Add Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
