import React from "react";
import { ViewType } from "../types";
import { MapPin, ArrowRight, Landmark, Mountain, Sparkles } from "lucide-react";

interface LandingViewProps {
  onNavigate: (view: ViewType) => void;
  onOpenConcierge: () => void;
}

export const LandingView: React.FC<LandingViewProps> = ({ onNavigate, onOpenConcierge }) => {
  return (
    <div className="relative min-h-[92vh] flex flex-col items-center justify-center px-4 sm:px-8 py-8 md:py-12 overflow-hidden">
      {/* Background Ambient Glowing Elements */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        <div 
          className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] rounded-full bg-[#dbe1ff] opacity-40 blur-3xl mix-blend-multiply animate-float" 
          style={{ animationDelay: "0s" }}
        />
        <div 
          className="absolute -bottom-[10%] -right-[10%] w-[55%] h-[55%] rounded-full bg-[#6ffbbe] opacity-35 blur-3xl mix-blend-multiply animate-float" 
          style={{ animationDelay: "2s" }}
        />
        <div 
          className="absolute top-[35%] left-[60%] w-[35%] h-[35%] rounded-full bg-[#ffdbcd] opacity-30 blur-3xl mix-blend-multiply animate-float" 
          style={{ animationDelay: "4s" }}
        />
      </div>

      <div className="relative z-10 w-full max-w-6xl flex flex-col items-center">
        {/* Hero Content */}
        <div className="text-center mb-8 md:mb-12">
          {/* Brand pill */}
          <div className="inline-flex items-center justify-center gap-2 mb-4 bg-white/70 backdrop-blur-md px-5 py-2 rounded-full border border-white/80 shadow-xs">
            <MapPin className="w-4 h-4 text-[#004ac6] fill-[#004ac6]" />
            <h1 className="font-bold text-lg bg-gradient-to-r from-[#004ac6] via-[#2563eb] to-[#006c49] bg-clip-text text-transparent">
              GlobeTrotter
            </h1>
          </div>

          <h2 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-[#191c1e] mb-4 max-w-4xl mx-auto leading-tight">
            Explore <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#004ac6] via-[#2563eb] to-[#006c49]">Incredible India</span>
          </h2>

          <p className="text-base sm:text-lg md:text-xl text-[#434655] max-w-2xl mx-auto mb-8 font-normal leading-relaxed">
            Discover the vibrant tapestry of cultures, landscapes, and heritage. Plan your perfect journey with our premium concierge experience.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => onNavigate("home")}
              id="landing-get-started-btn"
              className="group relative inline-flex items-center justify-center px-8 py-4 text-sm font-semibold text-white bg-gradient-to-r from-[#004ac6] to-[#006c49] rounded-full overflow-hidden shadow-md hover:shadow-lg transition-all duration-300 active:scale-95"
            >
              <span className="relative z-10 flex items-center gap-2">
                Get Started
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
              </span>
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
            </button>

            <button
              onClick={onOpenConcierge}
              id="landing-ai-concierge-btn"
              className="inline-flex items-center justify-center px-6 py-4 text-sm font-semibold text-[#004ac6] glass-panel rounded-full hover:bg-white transition-all shadow-xs border border-white"
            >
              <Sparkles className="w-4 h-4 text-[#004ac6] mr-2 animate-pulse" />
              AI Travel Concierge
            </button>
          </div>
        </div>

        {/* Bento Grid Collage */}
        <div className="w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 auto-rows-[160px] md:auto-rows-[190px]">
          {/* Taj Mahal (Large Focus: Span 2 cols, 2 rows) */}
          <div 
            onClick={() => onNavigate("plan")}
            className="sm:col-span-2 sm:row-span-2 relative rounded-3xl overflow-hidden group shadow-md border border-white/60 cursor-pointer transition-transform duration-500 hover:scale-[1.01]"
          >
            <div 
              className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
              style={{
                backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCdAm6T6WF10sEvGMMs8w86WQN1B-umGcI7DqCH71bv5XeLxPp0lcQzlRiwGE2uh0b2iERXUJj6dQwEn6RXfrlqFfR-XvZAZmrjFsdstipqzfh0u3VrtonG6crAyHs2qPgWY9leajMcfrrI8_CJF91rBqGD7FQYcImYotpmDHW07-sIY19kWeEkQMn7htPWQ_yI0GiNNJlQz7EmnBbIYYhOKhPjKApaHqiXws86sC6iJd5ToB3-JZvN')"
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 p-6 w-full">
              <div className="glass-panel inline-flex items-center gap-1.5 px-3 py-1 rounded-full mb-2 bg-white/30 text-white backdrop-blur-md">
                <Landmark className="w-3.5 h-3.5 text-white" />
                <span className="text-xs font-semibold text-white">Heritage</span>
              </div>
              <h3 className="text-2xl md:text-3xl font-bold text-white tracking-tight">Taj Mahal, Agra</h3>
              <p className="text-white/80 text-xs mt-1">Mughal wonder & reflecting pools</p>
            </div>
          </div>

          {/* Kerala Backwaters (Wide: Span 2 cols, 1 row) */}
          <div 
            onClick={() => onNavigate("home")}
            className="sm:col-span-2 sm:row-span-1 relative rounded-3xl overflow-hidden group shadow-md border border-white/60 cursor-pointer transition-transform duration-500 hover:scale-[1.01]"
          >
            <div 
              className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
              style={{
                backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCua8LJ_EJ03LPSPJsfUCUTum-vzlTPM_GPlfLyNtdY-92pO9XGqZyXCW2dlrrt-AFb4hHNpY2rChoKgPFPGni4Z6_M1E2QJD3elZyii5ggZcQIomHsXJFt8-_nxYiDQVQtF7zDi_e1CQXKv73WQSYCk92nno-_ZQOlW-2lxELfAEFBIgUG-p3gYLvt7LsfjJDTzicosC1TYURPmR_3nvHXnlbVW6CfwCtjQ3z00kobNzLblM6aPzYA')"
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 p-5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#6ffbbe] block mb-0.5">God's Own Country</span>
              <h3 className="text-xl md:text-2xl font-bold text-white">Kerala Backwaters</h3>
            </div>
          </div>

          {/* Himalayas (Tall: Span 1 col, 2 rows on desktop) */}
          <div 
            onClick={() => onNavigate("home")}
            className="sm:col-span-1 sm:row-span-2 relative rounded-3xl overflow-hidden group shadow-md border border-white/60 cursor-pointer transition-transform duration-500 hover:scale-[1.01]"
          >
            <div 
              className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
              style={{
                backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCbERVwURelUd2yt8l0kChZBqMFxA2x82Wa-QaaHewZC68-3AYFWYOzPNYWA4KEWSIfrdqYOrFsQZBNJpRrCa6dOPMko6e4kFQDHspRUwVziwQc2-w4wk340iz6XqbZD4ujuVoBZk7a2FtyYzvcok8xJPmHzgJUry4DccclrGkgvVsYoOMZAfE4ATcwF0pL6IPn9vK4JCrUellKm20O93ksoRoDxQD0quaoWfNUxTsW51tJDXs8CK5i')"
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 p-5">
              <div className="glass-panel inline-flex items-center gap-1.5 px-3 py-1 rounded-full mb-2 bg-white/30 text-white backdrop-blur-md">
                <Mountain className="w-3.5 h-3.5 text-white" />
                <span className="text-xs font-semibold text-white">Adventure</span>
              </div>
              <h3 className="text-xl md:text-2xl font-bold text-white">Himalayas</h3>
            </div>
          </div>

          {/* Mumbai Gateway of India */}
          <div 
            onClick={() => onNavigate("home")}
            className="sm:col-span-1 sm:row-span-1 relative rounded-3xl overflow-hidden group shadow-md border border-white/60 cursor-pointer transition-transform duration-500 hover:scale-[1.01]"
          >
            <div 
              className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
              style={{
                backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAc4CucCf_t8gna_l2OG6l3K37fCVG77XKZRIoZTKU1gam_PgGEifsU1dZdOKHUNh0zvsOMZ363SIogvw7h2FRPIioIBosmrOrSSs5rKK3U5sBL0Rys8_0nnMPc0l3S2n_3epOfL_FolwZjMp6IJmaVEXq5dpmM54Z9o9arlS_nT4LfNYW9qQPA5qLcUFwai3YBSZ27FwHPNrWY-r4YYEM_H71xLMDLcI0iQtXVY9Wq4CXnTPv5Bnrx')"
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
            <div className="absolute bottom-0 left-0 p-4">
              <h3 className="text-lg font-bold text-white">Mumbai</h3>
            </div>
          </div>

          {/* Rajasthan Desert */}
          <div 
            onClick={() => onNavigate("home")}
            className="sm:col-span-1 sm:row-span-1 relative rounded-3xl overflow-hidden group shadow-md border border-white/60 cursor-pointer transition-transform duration-500 hover:scale-[1.01]"
          >
            <div 
              className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
              style={{
                backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuCAo6rzLkie5AgAU6MpkJi5O-m5tm9J-cl3BvdVd_T43NsISc-pJ80n-UupEqQSG8YrqrTc67cNAvQjOoQBN8KMSdZtmSVsV8vNyIiDlTsMQu-ahvmmRhYFCCsjhc4JqJqNVODFR59OofNJG1ndSSFSZCafzS0MG3dJ6QlnJE4UGOFzeQ-Cx9E6PkcOskYz0taJuucXBRqxUvGr-7wYsnxiutHdgTHJOXeI3q9s1lBt_awrHBuptxtw')"
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
            <div className="absolute bottom-0 left-0 p-4">
              <h3 className="text-lg font-bold text-white">Rajasthan</h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
