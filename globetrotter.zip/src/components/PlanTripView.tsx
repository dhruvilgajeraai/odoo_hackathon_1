import React, { useState } from "react";
import { ViewType, Trip } from "../types";
import { 
  Search, 
  MapPin, 
  Calendar, 
  Users, 
  Plane, 
  Train, 
  Car, 
  Sparkles, 
  ArrowRight, 
  Minus, 
  Plus, 
  Building2,
  Loader2
} from "lucide-react";

interface PlanTripViewProps {
  onNavigate: (view: ViewType) => void;
  onTripGenerated: (trip: Trip) => void;
}

const CITIES_SUGGESTIONS = [
  { name: "Jaipur", state: "Rajasthan", tag: "Royal Palaces" },
  { name: "Jodhpur", state: "Rajasthan", tag: "Blue City" },
  { name: "Jaisalmer", state: "Rajasthan", tag: "Golden Dunes" },
  { name: "Udaipur", state: "Rajasthan", tag: "City of Lakes" },
  { name: "Agra", state: "Uttar Pradesh", tag: "Taj Mahal" },
  { name: "New Delhi", state: "Delhi NCR", tag: "Capital Heritage" },
  { name: "Mumbai", state: "Maharashtra", tag: "Gateway of India" },
  { name: "Varanasi", state: "Uttar Pradesh", tag: "Ganga Ghats" },
  { name: "Alleppey", state: "Kerala", tag: "Backwaters" },
  { name: "Leh Ladakh", state: "Ladakh", tag: "High Mountain Passes" },
  { name: "Goa", state: "Goa", tag: "Beaches & Nightlife" },
];

export const PlanTripView: React.FC<PlanTripViewProps> = ({ onNavigate, onTripGenerated }) => {
  const [destinationQuery, setDestinationQuery] = useState("Jaipur");
  const [showDropdown, setShowDropdown] = useState(false);
  const [adults, setAdults] = useState(2);
  const [days, setDays] = useState(4);
  const [transport, setTransport] = useState<"Flight" | "Train" | "Car">("Flight");
  const [budget, setBudget] = useState(50000);
  const [isGenerating, setIsGenerating] = useState(false);

  const filteredCities = CITIES_SUGGESTIONS.filter(c => 
    c.name.toLowerCase().includes(destinationQuery.toLowerCase()) ||
    c.state.toLowerCase().includes(destinationQuery.toLowerCase())
  );

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);

    try {
      const response = await fetch("/api/itinerary/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          destination: destinationQuery || "Jaipur, Rajasthan",
          days,
          travelers: `${adults} Adults`,
          budget,
          transport,
          preferences: ["Heritage", "Culture", "Royal Palaces", "Local Cuisine"],
        }),
      });

      const resJson = await response.json();
      if (resJson.success && resJson.data) {
        const genData = resJson.data;
        const newTrip: Trip = {
          id: `trip-${Date.now()}`,
          title: genData.title || `${destinationQuery} Tour`,
          destination: destinationQuery,
          dateRange: `Oct 12 - Oct ${12 + days - 1}, 2023`,
          travelersCount: adults,
          travelersText: `${adults} Adults`,
          status: "upcoming",
          totalDays: days,
          temperature: "29°C",
          weatherCondition: "Sunny",
          imageUrl: destinationQuery.toLowerCase().includes("kerala")
            ? "https://lh3.googleusercontent.com/aida-public/AB6AXuCua8LJ_EJ03LPSPJsfUCUTum-vzlTPM_GPlfLyNtdY-92pO9XGqZyXCW2dlrrt-AFb4hHNpY2rChoKgPFPGni4Z6_M1E2QJD3elZyii5ggZcQIomHsXJFt8-_nxYiDQVQtF7zDi_e1CQXKv73WQSYCk92nno-_ZQOlW-2lxELfAEFBIgUG-p3gYLvt7LsfjJDTzicosC1TYURPmR_3nvHXnlbVW6CfwCtjQ3z00kobNzLblM6aPzYA"
            : "https://lh3.googleusercontent.com/aida-public/AB6AXuBmybAypAzg_08ODufQJPuZjtrr9qdAWPNxiuCN84RtJUkNfXRi5zuESF4AvKpFOa2VoOVLWWltcVHC7HqyKz5gWk1CyzDMhUHK4lFQMQ4_QLLvaV27zIKcjZOC-PD13s51g2osOhUjFMzuW16i78HzUkOGJolVOCFgQKnhF3AxpCs542HfY0QQcHx0wsm7t25yKQJ1XPnMKhxB5pnKclizTs-qDxTBpS66Ho3sENRpl9PxA1TYJ_tZ",
          tags: ["Heritage", "₹₹ High-End"],
          priceCategory: budget > 100000 ? "₹₹₹ High-End" : "₹₹ Moderate",
          totalBudget: budget,
          paidAmount: Math.round(budget * 0.6),
          dueAmount: Math.round(budget * 0.4),
          transportMode: transport,
          days: genData.days || [],
        };
        onTripGenerated(newTrip);
        onNavigate("itinerary");
      } else {
        throw new Error("Generation returned unexpected data");
      }
    } catch (err) {
      console.warn("Using fallback local builder:", err);
      // Fallback trip setup
      const fallbackTrip: Trip = {
        id: `trip-${Date.now()}`,
        title: `${destinationQuery} Expedition`,
        destination: destinationQuery,
        dateRange: `Oct 12 - Oct ${12 + days - 1}, 2023`,
        travelersCount: adults,
        travelersText: `${adults} Adults`,
        status: "upcoming",
        totalDays: days,
        temperature: "28°C",
        imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuBmybAypAzg_08ODufQJPuZjtrr9qdAWPNxiuCN84RtJUkNfXRi5zuESF4AvKpFOa2VoOVLWWltcVHC7HqyKz5gWk1CyzDMhUHK4lFQMQ4_QLLvaV27zIKcjZOC-PD13s51g2osOhUjFMzuW16i78HzUkOGJolVOCFgQKnhF3AxpCs542HfY0QQcHx0wsm7t25yKQJ1XPnMKhxB5pnKclizTs-qDxTBpS66Ho3sENRpl9PxA1TYJ_tZ",
        tags: ["Cultural", "Adventure"],
        priceCategory: "₹₹ Moderate",
        totalBudget: budget,
        paidAmount: Math.round(budget * 0.5),
        dueAmount: Math.round(budget * 0.5),
        transportMode: transport,
        days: [
          {
            dayNumber: 1,
            title: `Day 1 (${destinationQuery})`,
            date: "Oct 12",
            activities: [
              {
                id: "act-fb-1",
                time: "09:00 AM",
                type: "hotel",
                title: "Check-in: Heritage Grand Palace",
                description: "Luxurious welcome with traditional garland and royal courtyard suite.",
                location: destinationQuery,
                cost: 15000,
                category: "Luxury",
                duration: "Overnight",
              },
              {
                id: "act-fb-2",
                time: "11:30 AM",
                type: "transport",
                title: `Private ${transport} Transfer to Old Fort`,
                description: "Seamless air-conditioned chauffeured transfer.",
                location: `${destinationQuery} Center`,
                cost: 800,
                category: "Transport",
                duration: "30 mins",
              },
              {
                id: "act-fb-3",
                time: "12:00 PM",
                type: "activity",
                title: "Explore Landmark Monuments & Palaces",
                description: "Guided architectural walkthrough of UNESCO heritage sites.",
                location: `${destinationQuery} Monument Complex`,
                cost: 500,
                category: "Cultural",
                duration: "2 Hours",
              },
            ],
          },
        ],
      };
      onTripGenerated(fallbackTrip);
      onNavigate("itinerary");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelectInspiration = (city: string, daysCount: number, b: number) => {
    setDestinationQuery(city);
    setDays(daysCount);
    setBudget(b);
  };

  return (
    <div className="relative min-h-[90vh] py-8 px-4 md:px-8 max-w-4xl mx-auto">
      {/* Background Subtle Map Texture */}
      <div 
        className="fixed inset-0 pointer-events-none opacity-10 bg-center bg-cover -z-10"
        style={{
          backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuDdv8TxSTI93_YbaeLfmdlDqzCgZeTdYp1I_U5ySUbneOUa_Q3bGuhF-PcZ1__7SRzRbKsjSZZDzLf-Cmcre2oocxcsjFD6daRlOQoOLrX347EanSsh8bPfUP_tG2IWL_CdMwruvW-JCctas_eF5Or3Xtis0CVk9bL8Y0H0suHMNbH-jn5qN2ydPYxoGWA0A_UVOjx35NPT39VZPbioM4mvJ8istOrDySXEz6GoEfXeDrNiwTDDHN_G')"
        }}
      />

      <div className="text-center mb-8">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#191c1e] tracking-tight">
          Plan Your Indian Adventure
        </h1>
        <p className="text-sm text-[#434655] mt-1.5 font-normal">
          AI-powered concierge creates realistic day-by-day itineraries, verified costs, and route maps
        </p>
      </div>

      <form 
        onSubmit={handleGenerate}
        className="glass-panel rounded-3xl p-6 sm:p-8 md:p-10 flex flex-col gap-6 shadow-md border border-white"
      >
        {/* Destination Autocomplete */}
        <div className="flex flex-col gap-2 relative">
          <label className="text-xs font-bold text-[#434655] uppercase tracking-wider">
            Destination
          </label>
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#737686]" />
            <input
              id="plan-destination-input"
              type="text"
              required
              value={destinationQuery}
              onChange={(e) => {
                setDestinationQuery(e.target.value);
                setShowDropdown(true);
              }}
              onFocus={() => setShowDropdown(true)}
              placeholder="Search cities (e.g., Jaipur, Udaipur, Varanasi, Goa, Munnar)"
              className="w-full pl-11 pr-4 py-3.5 rounded-xl border border-black/10 bg-white/80 focus:bg-white focus:ring-2 focus:ring-[#004ac6] focus:border-transparent transition-all text-sm font-medium text-[#191c1e]"
            />
          </div>

          {/* Autocomplete dropdown simulation */}
          {showDropdown && filteredCities.length > 0 && (
            <div 
              className="absolute top-full left-0 w-full mt-1.5 bg-white rounded-xl shadow-xl border border-black/10 overflow-hidden z-30 divide-y divide-black/5"
            >
              {filteredCities.slice(0, 5).map((city) => (
                <div
                  key={city.name}
                  onClick={() => {
                    setDestinationQuery(`${city.name}, ${city.state}`);
                    setShowDropdown(false);
                  }}
                  className="px-4 py-3 hover:bg-[#f2f4f6] cursor-pointer flex items-center justify-between text-xs transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <Building2 className="w-4 h-4 text-[#004ac6]" />
                    <span className="font-semibold text-sm text-[#191c1e]">{city.name}</span>
                    <span className="text-[#737686]">{city.state}</span>
                  </div>
                  <span className="text-[10px] font-semibold bg-[#dbe1ff] text-[#004ac6] px-2 py-0.5 rounded-full">
                    {city.tag}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Dates & Travelers */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Duration in Days */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-bold text-[#434655] uppercase tracking-wider">
              Duration
            </label>
            <div className="flex items-center justify-between bg-white/80 border border-black/10 rounded-xl p-2 px-3">
              <button
                type="button"
                onClick={() => setDays(Math.max(1, days - 1))}
                className="w-8 h-8 rounded-full hover:bg-[#f2f4f6] flex items-center justify-center text-[#004ac6] transition-colors"
              >
                <Minus className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-2 text-sm font-semibold text-[#191c1e]">
                <Calendar className="w-4 h-4 text-[#737686]" />
                <span>{days} {days === 1 ? "Day" : "Days"}</span>
              </div>
              <button
                type="button"
                onClick={() => setDays(Math.min(14, days + 1))}
                className="w-8 h-8 rounded-full hover:bg-[#f2f4f6] flex items-center justify-center text-[#004ac6] transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Travelers Counter */}
          <div className="flex flex-col gap-2">
            <label className="text-xs font-bold text-[#434655] uppercase tracking-wider">
              Travelers
            </label>
            <div className="flex items-center justify-between bg-white/80 border border-black/10 rounded-xl p-2 px-3">
              <button
                type="button"
                onClick={() => setAdults(Math.max(1, adults - 1))}
                className="w-8 h-8 rounded-full hover:bg-[#f2f4f6] flex items-center justify-center text-[#004ac6] transition-colors"
              >
                <Minus className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-2 text-sm font-semibold text-[#191c1e]">
                <Users className="w-4 h-4 text-[#737686]" />
                <span>{adults} {adults === 1 ? "Adult" : "Adults"}</span>
              </div>
              <button
                type="button"
                onClick={() => setAdults(Math.min(8, adults + 1))}
                className="w-8 h-8 rounded-full hover:bg-[#f2f4f6] flex items-center justify-center text-[#004ac6] transition-colors"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Transport Type */}
        <div className="flex flex-col gap-2">
          <label className="text-xs font-bold text-[#434655] uppercase tracking-wider">
            Transport Type
          </label>
          <div className="grid grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => setTransport("Flight")}
              className={`flex flex-col items-center justify-center py-3.5 rounded-xl transition-all cursor-pointer ${
                transport === "Flight"
                  ? "border-2 border-[#004ac6] bg-[#2563eb]/10 text-[#004ac6] font-bold shadow-xs"
                  : "border border-black/10 bg-white/70 text-[#434655] hover:bg-white"
              }`}
            >
              <Plane className="w-5 h-5 mb-1" />
              <span className="text-xs">Flight</span>
            </button>

            <button
              type="button"
              onClick={() => setTransport("Train")}
              className={`flex flex-col items-center justify-center py-3.5 rounded-xl transition-all cursor-pointer ${
                transport === "Train"
                  ? "border-2 border-[#004ac6] bg-[#2563eb]/10 text-[#004ac6] font-bold shadow-xs"
                  : "border border-black/10 bg-white/70 text-[#434655] hover:bg-white"
              }`}
            >
              <Train className="w-5 h-5 mb-1" />
              <span className="text-xs">Train</span>
            </button>

            <button
              type="button"
              onClick={() => setTransport("Car")}
              className={`flex flex-col items-center justify-center py-3.5 rounded-xl transition-all cursor-pointer ${
                transport === "Car"
                  ? "border-2 border-[#004ac6] bg-[#2563eb]/10 text-[#004ac6] font-bold shadow-xs"
                  : "border border-black/10 bg-white/70 text-[#434655] hover:bg-white"
              }`}
            >
              <Car className="w-5 h-5 mb-1" />
              <span className="text-xs">Chauffeur / Car</span>
            </button>
          </div>
        </div>

        {/* Budget Slider */}
        <div className="flex flex-col gap-2">
          <div className="flex justify-between items-center">
            <label className="text-xs font-bold text-[#434655] uppercase tracking-wider" htmlFor="budget-slider">
              Budget (Total)
            </label>
            <span className="text-base font-extrabold text-[#004ac6] bg-[#dbe1ff]/60 px-3 py-0.5 rounded-full">
              ₹{budget.toLocaleString("en-IN")}
            </span>
          </div>
          <input
            id="budget-slider"
            type="range"
            min="10000"
            max="500000"
            step="5000"
            value={budget}
            onChange={(e) => setBudget(Number(e.target.value))}
            className="w-full h-2 bg-[#e0e3e5] rounded-lg appearance-none cursor-pointer accent-[#004ac6]"
          />
          <div className="flex justify-between text-xs text-[#737686] font-medium">
            <span>₹10K</span>
            <span>₹250K</span>
            <span>₹500K+</span>
          </div>
        </div>

        {/* Create / Generate Button */}
        <button
          type="submit"
          disabled={isGenerating}
          id="generate-itinerary-submit-btn"
          className="mt-2 w-full py-4 bg-gradient-to-r from-[#004ac6] via-[#2563eb] to-[#006c49] text-white rounded-xl font-bold text-sm hover:opacity-95 active:scale-[0.98] transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Generating AI Itinerary with Live Route...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5 text-[#6ffbbe]" />
              <span>Generate Itinerary</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>

      {/* Trending Inspirations */}
      <div className="mt-8">
        <h3 className="text-xs font-bold text-[#737686] uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-[#004ac6]" />
          Trending Inspirations
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            type="button"
            onClick={() => handleSelectInspiration("Golden Triangle (Delhi, Agra, Jaipur)", 5, 65000)}
            className="glass-panel p-3.5 rounded-2xl text-left hover:border-[#004ac6]/50 transition-all flex items-center gap-3.5 cursor-pointer group"
          >
            <div className="w-14 h-14 rounded-xl overflow-hidden shrink-0 bg-[#eceef0]">
              <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBAvdeT_rJmma6yigK0A7c1ucZY1u8Ye5f0IdVRqJn99TG1nrNmF4CP4--dsvfMEHPzPBwkP7aljgoCF3htHnVDsLNDCx5LnZCTXJmBfKWQJzrGjxAoAZIFSIi6OYkifu-c5W9f9TU7_Ku6DdNcnyU1NQI9hD7thIAawn3TVlIfwtEs0OpeM77J2p3RJ3EU9zYAjBVv812WiyAcUFadbWGrLHIJQ9MEIIBUoj_BzXMwsSWtR7gRtrEs" 
                alt="Taj Mahal" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            </div>
            <div>
              <div className="font-bold text-sm text-[#191c1e] group-hover:text-[#004ac6] transition-colors">
                Golden Triangle Tour
              </div>
              <div className="text-xs text-[#737686]">Delhi, Agra, Jaipur • 5 Days</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => handleSelectInspiration("Kerala Backwaters & Munnar", 6, 75000)}
            className="glass-panel p-3.5 rounded-2xl text-left hover:border-[#004ac6]/50 transition-all flex items-center gap-3.5 cursor-pointer group"
          >
            <div className="w-14 h-14 rounded-xl overflow-hidden shrink-0 bg-[#eceef0]">
              <img 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBr9Bv0zVQ7XfSVRpGwdPjaLGdhl4a-ZnIhMZ2Vj3fJ3tnZ2dDppEYV1ZZT_T4sxLWyrxCM_EjkjtwluCpDGdA8wY5hW_FVvc5dV8UNFlu8Fwnt9_CxaGj7scIenNBSbjz2pHj_Wf9YHHzMA7kTabrjlF8WYfJHX4wkzWlyGIbPTED1EdQQLYDXtzb9UoImbI4f2Uds_iu1hqhhccKPbBLZMO7c_kflfxVJwjOY7vQPv4I4jqFGPIQy" 
                alt="Kerala" 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            </div>
            <div>
              <div className="font-bold text-sm text-[#191c1e] group-hover:text-[#004ac6] transition-colors">
                Kerala Retreat
              </div>
              <div className="text-xs text-[#737686]">Munnar, Alleppey • 6 Days</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
