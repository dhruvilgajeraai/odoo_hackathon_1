import React, { useState } from "react";
import { ViewType, Trip } from "../types";
import { 
  Wallet, 
  Download, 
  Plus, 
  Hotel, 
  Plane, 
  Compass, 
  Utensils, 
  CheckCircle2, 
  Clock, 
  Check, 
  ArrowUpRight,
  TrendingUp
} from "lucide-react";

interface BudgetViewProps {
  currentTrip: Trip | null;
  onNavigate: (view: ViewType) => void;
}

interface ExpenseItem {
  id: string;
  date: string;
  category: "Hotels" | "Transport" | "Activities" | "Dining";
  title: string;
  amount: number;
  status: "paid" | "due";
}

const INITIAL_EXPENSES: ExpenseItem[] = [
  {
    id: "exp-1",
    date: "Oct 12",
    category: "Transport",
    title: "Flight BOM → DEL (IND-624)",
    amount: 12500,
    status: "paid",
  },
  {
    id: "exp-2",
    date: "Oct 12",
    category: "Hotels",
    title: "The Imperial New Delhi Deposit",
    amount: 15000,
    status: "paid",
  },
  {
    id: "exp-3",
    date: "Oct 13",
    category: "Activities",
    title: "Taj Mahal VIP Sunrise Entry & Guide",
    amount: 2200,
    status: "paid",
  },
  {
    id: "exp-4",
    date: "Oct 13",
    category: "Dining",
    title: "Peshawri Mughlai Dinner Agra",
    amount: 3200,
    status: "paid",
  },
  {
    id: "exp-5",
    date: "Oct 14",
    category: "Hotels",
    title: "Rambagh Palace Jaipur Booking",
    amount: 28000,
    status: "due",
  },
  {
    id: "exp-6",
    date: "Oct 14",
    category: "Transport",
    title: "Chauffeur Golden Triangle Tour",
    amount: 6500,
    status: "due",
  },
];

export const BudgetView: React.FC<BudgetViewProps> = ({ currentTrip, onNavigate }) => {
  const [expenses, setExpenses] = useState<ExpenseItem[]>(INITIAL_EXPENSES);
  const [filterCategory, setFilterCategory] = useState<string>("All");
  const [downloaded, setDownloaded] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  // Form state
  const [title, setTitle] = useState("");
  const [amount, setAmount] = useState(2500);
  const [category, setCategory] = useState<"Hotels" | "Transport" | "Activities" | "Dining">("Activities");
  const [date, setDate] = useState("Oct 15");
  const [status, setStatus] = useState<"paid" | "due">("paid");

  const totalCost = expenses.reduce((acc, curr) => acc + curr.amount, 0);
  const paidCost = expenses.filter(e => e.status === "paid").reduce((acc, curr) => acc + curr.amount, 0);
  const dueCost = expenses.filter(e => e.status === "due").reduce((acc, curr) => acc + curr.amount, 0);

  // Category sums
  const hotelsSum = expenses.filter(e => e.category === "Hotels").reduce((a, b) => a + b.amount, 0);
  const transportSum = expenses.filter(e => e.category === "Transport").reduce((a, b) => a + b.amount, 0);
  const activitiesSum = expenses.filter(e => e.category === "Activities").reduce((a, b) => a + b.amount, 0);
  const diningSum = expenses.filter(e => e.category === "Dining").reduce((a, b) => a + b.amount, 0);

  const categoriesBreakdown = [
    { name: "Hotels", amount: hotelsSum, color: "bg-[#004ac6]", text: "text-[#004ac6]", percent: Math.round((hotelsSum / totalCost) * 100) || 40 },
    { name: "Transport", amount: transportSum, color: "bg-[#006c49]", text: "text-[#006c49]", percent: Math.round((transportSum / totalCost) * 100) || 25 },
    { name: "Activities", amount: activitiesSum, color: "bg-[#943700]", text: "text-[#943700]", percent: Math.round((activitiesSum / totalCost) * 100) || 20 },
    { name: "Dining", amount: diningSum, color: "bg-[#795548]", text: "text-[#795548]", percent: Math.round((diningSum / totalCost) * 100) || 15 },
  ];

  const filteredExpenses = expenses.filter(e => filterCategory === "All" || e.category === filterCategory);

  const handleExport = () => {
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 2500);
  };

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newExp: ExpenseItem = {
      id: `exp-${Date.now()}`,
      title,
      amount: Number(amount) || 0,
      category,
      date,
      status,
    };

    setExpenses([newExp, ...expenses]);
    setTitle("");
    setShowAddModal(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#004ac6] bg-[#dbe1ff] px-2.5 py-0.5 rounded-full inline-block mb-1">
            Financial Concierge
          </span>
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#191c1e] tracking-tight">
            Trip Budget & Expenses
          </h1>
          <p className="text-xs sm:text-sm text-[#737686] mt-0.5">
            Real-time breakdown of bookings, transfers, permits, and dining across India
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExport}
            id="export-budget-csv-btn"
            className="px-4 py-2.5 rounded-xl border border-black/10 bg-white hover:bg-[#f2f4f6] text-xs font-bold text-[#191c1e] transition-colors flex items-center gap-1.5 shadow-xs"
          >
            {downloaded ? <Check className="w-4 h-4 text-[#006c49]" /> : <Download className="w-4 h-4" />}
            <span>{downloaded ? "Report Exported!" : "Export CSV"}</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            id="add-expense-btn"
            className="px-4 py-2.5 rounded-xl bg-[#004ac6] text-white hover:bg-[#2563eb] text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add Expense</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6">
        <div className="bg-white rounded-2xl border border-black/5 p-6 shadow-xs space-y-1">
          <span className="text-xs font-bold text-[#737686] uppercase tracking-wider">
            Total Estimated Cost
          </span>
          <div className="text-3xl sm:text-4xl font-extrabold text-[#191c1e]">
            ₹{totalCost.toLocaleString("en-IN")}
          </div>
          <div className="text-xs text-[#006c49] font-semibold flex items-center gap-1 pt-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Within targeted trip budget</span>
          </div>
        </div>

        <div className="bg-[#6ffbbe]/15 rounded-2xl border border-[#006c49]/20 p-6 shadow-xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#006c49] uppercase tracking-wider">
              Paid / Confirmed
            </span>
            <CheckCircle2 className="w-4 h-4 text-[#006c49]" />
          </div>
          <div className="text-3xl sm:text-4xl font-extrabold text-[#006c49]">
            ₹{paidCost.toLocaleString("en-IN")}
          </div>
          <div className="text-xs text-[#006c49]/80 font-medium">
            {Math.round((paidCost / totalCost) * 100)}% of total paid upfront
          </div>
        </div>

        <div className="bg-[#ffdbcd]/30 rounded-2xl border border-[#943700]/20 p-6 shadow-xs space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#943700] uppercase tracking-wider">
              Due on Arrival
            </span>
            <Clock className="w-4 h-4 text-[#943700]" />
          </div>
          <div className="text-3xl sm:text-4xl font-extrabold text-[#943700]">
            ₹{dueCost.toLocaleString("en-IN")}
          </div>
          <div className="text-xs text-[#943700]/80 font-medium">
            Payable directly at hotels & chauffeurs
          </div>
        </div>
      </div>

      {/* Main Grid: Left Donut Breakdown / Right Daily Expense Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        {/* Spending Breakdown */}
        <div className="bg-white rounded-2xl border border-black/5 p-6 shadow-xs space-y-6">
          <h2 className="text-base font-bold text-[#191c1e]">
            Spending Breakdown
          </h2>

          {/* Segmented Progress Bar & Visual Donut */}
          <div className="space-y-3">
            <div className="h-4 rounded-full overflow-hidden flex bg-black/5">
              {categoriesBreakdown.map((cat) => (
                <div
                  key={cat.name}
                  className={`${cat.color} transition-all duration-500`}
                  style={{ width: `${cat.percent}%` }}
                  title={`${cat.name}: ${cat.percent}%`}
                />
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              {categoriesBreakdown.map((cat) => (
                <div key={cat.name} className="p-3 rounded-xl bg-[#f7f9fb] space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2.5 h-2.5 rounded-full ${cat.color}`} />
                    <span className="text-xs font-bold text-[#434655]">{cat.name}</span>
                  </div>
                  <div className="text-sm font-extrabold text-[#191c1e]">
                    ₹{cat.amount.toLocaleString("en-IN")}
                  </div>
                  <div className="text-[10px] text-[#737686]">
                    {cat.percent}% of budget
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Smart Budget Advice */}
          <div className="p-4 rounded-xl bg-[#dbe1ff]/40 border border-[#004ac6]/20 text-xs text-[#004ac6] space-y-1">
            <div className="font-bold flex items-center gap-1.5">
              <span>Smart Saving Concierge</span>
            </div>
            <p className="text-[#00174b]/80 leading-relaxed">
              Book the Taj Mahal e-ticket online to save ₹150 convenience surcharge per ticket.
            </p>
          </div>
        </div>

        {/* Expense Timeline Table */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-black/5 p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h2 className="text-base font-bold text-[#191c1e]">
              Daily Expense Records
            </h2>
            <div className="flex gap-1.5 overflow-x-auto hide-scroll">
              {["All", "Hotels", "Transport", "Activities", "Dining"].map((c) => (
                <button
                  key={c}
                  onClick={() => setFilterCategory(c)}
                  className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                    filterCategory === c
                      ? "bg-[#004ac6] text-white"
                      : "bg-[#f2f4f6] text-[#434655] hover:bg-[#e0e3e5]"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-black/5">
            {filteredExpenses.map((exp) => {
              let IconComponent = Compass;
              if (exp.category === "Hotels") IconComponent = Hotel;
              if (exp.category === "Transport") IconComponent = Plane;
              if (exp.category === "Dining") IconComponent = Utensils;

              return (
                <div 
                  key={exp.id} 
                  className="py-3.5 flex items-center justify-between gap-4 hover:bg-[#f7f9fb] px-2 rounded-xl transition-colors"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-9 h-9 rounded-xl bg-[#f2f4f6] flex items-center justify-center shrink-0">
                      <IconComponent className="w-4 h-4 text-[#004ac6]" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#191c1e]">{exp.title}</span>
                        <span className="text-[10px] text-[#737686] bg-black/5 px-2 py-0.2 rounded-full">{exp.date}</span>
                      </div>
                      <span className="text-[11px] text-[#737686]">{exp.category}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-sm font-extrabold text-[#191c1e]">
                      ₹{exp.amount.toLocaleString("en-IN")}
                    </div>
                    <span 
                      className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                        exp.status === "paid" 
                          ? "bg-[#6ffbbe]/30 text-[#006c49]" 
                          : "bg-[#ffdbcd] text-[#943700]"
                      }`}
                    >
                      {exp.status === "paid" ? "Paid" : "Due on Arrival"}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Add Expense Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-black/10 space-y-4">
            <h3 className="text-lg font-bold text-[#191c1e]">
              Add Expense Item
            </h3>

            <form onSubmit={handleAddExpense} className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-[#737686] block mb-1">Expense Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Amber Fort Elephant & Guide"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-[#737686] block mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                  >
                    <option value="Hotels">Hotels</option>
                    <option value="Transport">Transport</option>
                    <option value="Activities">Activities</option>
                    <option value="Dining">Dining</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-[#737686] block mb-1">Amount (₹)</label>
                  <input
                    type="number"
                    required
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs font-bold text-[#737686] block mb-1">Date</label>
                  <input
                    type="text"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    placeholder="e.g., Oct 15"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-[#737686] block mb-1">Status</label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                  >
                    <option value="paid">Paid</option>
                    <option value="due">Due</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-black/10">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-[#737686] hover:bg-[#eceef0]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-[#004ac6] text-white hover:bg-[#2563eb]"
                >
                  Save Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
