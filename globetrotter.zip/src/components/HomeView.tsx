import React, { useState } from "react";
import { ViewType, Destination } from "../types";
import { 
  Search, 
  Heart, 
  MapPin, 
  PlaneTakeoff, 
  Camera, 
  Sun, 
  CloudRain, 
  Cloud, 
  Compass, 
  ArrowRight, 
  Plus, 
  MoreHorizontal, 
  Sparkles 
} from "lucide-react";
import { FEATURED_DESTINATIONS, LIVE_WEATHER_DATA } from "../data/mockData";

interface HomeViewProps {
  onNavigate: (view: ViewType) => void;
  onSelectDestination: (dest: Destination) => void;
  onOpenConcierge: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ 
  onNavigate, 
  onSelectDestination,
  onOpenConcierge 
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTag, setSelectedTag] = useState<string>("All");
  const [destinations, setDestinations] = useState<Destination[]>(FEATURED_DESTINATIONS);

  const tags = ["All", "Cultural", "Adventure", "₹₹ High-End", "Nature", "Heritage", "Relaxation"];

  const toggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setDestinations(prev => prev.map(d => d.id === id ? { ...d, isFavorite: !d.isFavorite } : d));
  };

  const filteredDestinations = destinations.filter(dest => {
    const matchesSearch = dest.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          dest.state.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          dest.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTag = selectedTag === "All" || dest.tags.includes(selectedTag as any);
    return matchesSearch && matchesTag;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-8 space-y-8">
      {/* Hero Section with Map & Glass Search */}
      <section className="relative h-[480px] md:h-[560px] rounded-3xl overflow-hidden shadow-sm border border-white/50 group">
        {/* Stylized Aerial Map Background */}
        <div 
          className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 group-hover:scale-[1.02]"
          style={{
            backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBekHK6hHbsSr0SjIWvphLVRf6ZesHB2-kAX2IzrEbU2Pop43FTQOWa8OjZl_sRrjaakJb6nMa98PTmcHNcgTqSr74l0DaD2hb48ZpHaiMfuAhqDtOpsn4l9Y4OvkG_mfh0UFfCq5qPbjGowEEKdKSszujXQVzI1JU9pKfSUkwRstmAl5Elb_Ovy24j3oIqK5XrGuYC7M57op7KLU69Z0ezVEkvEnQ4p3ExI7rpSB2JjB3Ol7Ei6A78')"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent pointer-events-none" />

        {/* Interactive Map Pins */}
        <button 
          onClick={() => {
            const dest = destinations.find(d => d.id === "jaipur");
            if (dest) onSelectDestination(dest);
          }}
          className="absolute top-1/3 left-1/4 bg-[#004ac6] text-white rounded-full p-2.5 shadow-lg hover:scale-110 transition-transform active:scale-95 group/pin z-20 cursor-pointer"
        >
          <MapPin className="w-4 h-4 fill-white" />
          <span className="absolute -top-9 left-1/2 -translate-x-1/2 glass-panel text-[#191c1e] px-2.5 py-1 rounded-md text-xs font-semibold opacity-0 group-hover/pin:opacity-100 transition-opacity whitespace-nowrap shadow-sm">
            Jaipur (Royal Forts)
          </span>
        </button>

        <button 
          onClick={() => {
            const dest = destinations.find(d => d.id === "mumbai");
            if (dest) onSelectDestination(dest);
          }}
          className="absolute top-1/2 left-1/3 bg-white text-[#004ac6] rounded-full p-2.5 shadow-lg hover:scale-110 transition-transform active:scale-95 group/pin border border-[#004ac6]/30 z-20 cursor-pointer"
        >
          <MapPin className="w-4 h-4 fill-[#004ac6]" />
          <span className="absolute -top-9 left-1/2 -translate-x-1/2 glass-panel text-[#191c1e] px-2.5 py-1 rounded-md text-xs font-semibold opacity-0 group-hover/pin:opacity-100 transition-opacity whitespace-nowrap shadow-sm">
            Mumbai (Coastal Gateway)
          </span>
        </button>

        <button 
          onClick={() => {
            const dest = destinations.find(d => d.id === "kerala");
            if (dest) onSelectDestination(dest);
          }}
          className="absolute bottom-1/3 right-1/3 bg-[#006c49] text-white rounded-full p-2.5 shadow-lg hover:scale-110 transition-transform active:scale-95 group/pin z-20 cursor-pointer"
        >
          <MapPin className="w-4 h-4 fill-white" />
          <span className="absolute -top-9 left-1/2 -translate-x-1/2 glass-panel text-[#191c1e] px-2.5 py-1 rounded-md text-xs font-semibold opacity-0 group-hover/pin:opacity-100 transition-opacity whitespace-nowrap shadow-sm">
            Kerala (Backwaters)
          </span>
        </button>

        {/* Content & Glass Search Overlay */}
        <div className="absolute inset-x-0 bottom-0 p-6 md:p-8 z-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="text-white space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-semibold tracking-wider uppercase mb-1">
              <Sparkles className="w-3.5 h-3.5 text-[#6ffbbe]" />
              Luxury Concierge Edition
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold drop-shadow-md text-white">
              Discover India
            </h1>
            <p className="text-base sm:text-lg text-white/90 font-normal">
              Curated experiences across the subcontinent with instant itinerary design.
            </p>
          </div>

          {/* Glass Search Bar */}
          <div className="glass-panel rounded-2xl p-4 w-full md:w-auto md:min-w-[420px] shadow-lg flex flex-col gap-3">
            <div className="relative flex items-center">
              <Search className="w-5 h-5 absolute left-3.5 text-[#737686]" />
              <input
                id="home-destination-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search India (e.g., Delhi, Mumbai, Jaipur...)"
                className="w-full bg-white/70 border border-white/80 text-[#191c1e] rounded-xl py-3 pl-11 pr-4 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#004ac6] focus:bg-white transition-all placeholder:text-[#737686]"
              />
            </div>
            <div className="flex gap-2 overflow-x-auto hide-scroll pb-1">
              {tags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setSelectedTag(tag)}
                  className={`shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full border transition-all shadow-xs ${
                    selectedTag === tag
                      ? "bg-[#004ac6] text-white border-[#004ac6]"
                      : "bg-white/70 hover:bg-white text-[#434655] border-white/80"
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Main Grid: Left 2 Cols (Destinations + Recent Journeys) / Right 1 Col (Weather & Recommendations) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        {/* Left 2 Columns */}
        <div className="lg:col-span-2 space-y-8">
          {/* Featured Destinations */}
          <section>
            <div className="flex justify-between items-end mb-4">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold text-[#191c1e]">
                  Featured Destinations
                </h2>
                <p className="text-sm text-[#737686] mt-0.5">Hand-picked iconic journeys with verified routes</p>
              </div>
              <button 
                onClick={() => onNavigate("plan")}
                id="view-all-destinations-btn"
                className="text-[#004ac6] text-sm font-semibold hover:underline flex items-center gap-1"
              >
                <span>View All</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="flex overflow-x-auto gap-4 md:gap-6 hide-scroll pb-4 -mx-4 px-4 md:mx-0 md:px-0">
              {filteredDestinations.map((dest) => (
                <div
                  key={dest.id}
                  onClick={() => onSelectDestination(dest)}
                  id={`destination-card-${dest.id}`}
                  className="min-w-[280px] w-[280px] md:w-[320px] shrink-0 bg-white rounded-2xl border border-black/5 overflow-hidden shadow-xs relative group cursor-pointer hover:shadow-md transition-all hover:-translate-y-1"
                >
                  <div className="h-48 relative overflow-hidden bg-[#eceef0]">
                    <img 
                      src={dest.imageUrl} 
                      alt={dest.name} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
                    
                    {/* Favorite Heart Button */}
                    <button
                      onClick={(e) => toggleFavorite(dest.id, e)}
                      id={`favorite-btn-${dest.id}`}
                      className="absolute top-3 right-3 glass-panel rounded-full p-2 flex items-center justify-center hover:bg-white transition-colors z-10 cursor-pointer shadow-xs"
                      title="Save to Wishlist"
                    >
                      <Heart 
                        className={`w-4 h-4 ${dest.isFavorite ? "fill-[#ba1a1a] text-[#ba1a1a]" : "text-[#434655]"}`} 
                      />
                    </button>

                    {/* Tag Badges */}
                    <div className="absolute bottom-3 left-3 flex gap-1.5 z-10 flex-wrap">
                      {dest.tags.map((tag) => (
                        <span 
                          key={tag} 
                          className="bg-black/60 backdrop-blur-md text-white text-[10px] font-semibold px-2.5 py-0.5 rounded-full"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="p-4">
                    <div className="flex justify-between items-baseline mb-1">
                      <h3 className="text-xl font-bold text-[#191c1e] group-hover:text-[#004ac6] transition-colors">
                        {dest.name}
                      </h3>
                      <span className="text-xs font-semibold text-[#006c49]">
                        ₹{dest.avgCostPerDay.toLocaleString("en-IN")}/day
                      </span>
                    </div>
                    <p className="text-xs text-[#737686] line-clamp-2">
                      {dest.description}
                    </p>
                    <div className="mt-3 pt-3 border-t border-black/5 flex items-center justify-between text-xs text-[#004ac6] font-semibold">
                      <span>Explore Itinerary</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Your Recent Journeys Bento */}
          <section>
            <h2 className="text-2xl md:text-3xl font-bold text-[#191c1e] mb-4">
              Your Recent Journeys
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {/* Completed Journey Card */}
              <div 
                onClick={() => onNavigate("trips")}
                className="sm:col-span-2 rounded-2xl overflow-hidden relative group cursor-pointer border border-black/5 shadow-xs min-h-[220px]"
              >
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                  style={{
                    backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuBvsDJigIbsun5Rd3r0WB7ISOnPny6wp1wSckglCKfoIFQKAfTJX7QWda8WqcNpBQLPuOupeplW2X6rDkeL7u5XqvqfPA8NnfXxw-KiauDGVthMuNlIL3sKnQHdrjKfgSJnc1jqNLDJdiSdCmLgej3zCDWuu0duV7Yo5gMBffgbsOXXy-4OnxCbiz_zXBTXbVUc_1zSDG8TQhXM66PquGHVeCG6tH080gUbstP2-700147H8P13obqY')"
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 p-5 w-full">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#6ffbbe] bg-black/40 px-2 py-0.5 rounded-full inline-block mb-1">
                    Completed Journey
                  </span>
                  <h3 className="text-xl font-bold text-white">Kerala Backwaters</h3>
                  <p className="text-xs text-white/80 mt-0.5">Completed Oct 2023 • 7 Days Houseboat & Ayurveda</p>
                </div>
              </div>

              {/* Flight History & Trip Gallery Actions */}
              <div className="grid grid-cols-2 sm:grid-cols-1 gap-4">
                <div 
                  onClick={() => onNavigate("calendar")}
                  className="rounded-2xl bg-white border border-black/5 p-4 flex flex-col justify-center items-center text-center cursor-pointer hover:bg-[#f2f4f6] transition-colors shadow-xs"
                >
                  <div className="w-10 h-10 rounded-full bg-[#dbe1ff] flex items-center justify-center mb-2 text-[#004ac6]">
                    <PlaneTakeoff className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-bold text-[#191c1e]">Flight History</span>
                  <span className="text-[11px] text-[#737686]">12 Flights Logged</span>
                </div>

                <div 
                  onClick={() => onNavigate("profile")}
                  className="rounded-2xl bg-white border border-black/5 p-4 flex flex-col justify-center items-center text-center cursor-pointer hover:bg-[#f2f4f6] transition-colors shadow-xs"
                >
                  <div className="w-10 h-10 rounded-full bg-[#6ffbbe]/30 flex items-center justify-center mb-2 text-[#006c49]">
                    <Camera className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-bold text-[#191c1e]">Trip Gallery</span>
                  <span className="text-[11px] text-[#737686]">156 Memories</span>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Right Column: Widgets */}
        <div className="space-y-6">
          {/* Live Weather Conditions Widget */}
          <div className="bg-white rounded-2xl border border-black/5 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold text-[#737686] uppercase tracking-wider">
                Live Indian Weather
              </h3>
              <MoreHorizontal className="w-4 h-4 text-[#737686]" />
            </div>

            <div className="space-y-3">
              {LIVE_WEATHER_DATA.slice(0, 3).map((w) => (
                <div 
                  key={w.city}
                  className="flex items-center justify-between p-3 rounded-xl bg-[#f7f9fb] hover:bg-[#eceef0] transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-white flex items-center justify-center shadow-xs">
                      {w.condition === "Sunny" && <Sun className="w-5 h-5 text-[#bc4800]" />}
                      {w.condition === "Light Rain" && <CloudRain className="w-5 h-5 text-[#004ac6]" />}
                      {w.condition === "Cloudy" && <Cloud className="w-5 h-5 text-[#737686]" />}
                      {w.condition === "Partly Cloudy" && <Sun className="w-5 h-5 text-[#bc4800]" />}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#191c1e]">{w.city}</div>
                      <div className="text-xs text-[#737686]">{w.condition}</div>
                    </div>
                  </div>
                  <div className="text-xl font-bold text-[#191c1e]">{w.temp}°</div>
                </div>
              ))}
            </div>
          </div>

          {/* Personalized Recommendation Banner */}
          <div className="bg-gradient-to-br from-[#dbe1ff] via-[#b4c5ff] to-[#6ffbbe]/40 rounded-2xl border border-[#004ac6]/20 p-6 shadow-xs relative overflow-hidden">
            <div className="absolute -right-8 -top-8 opacity-20 transform rotate-12 pointer-events-none">
              <Compass className="w-36 h-36 text-[#004ac6]" />
            </div>
            
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#004ac6] bg-white/70 px-2 py-0.5 rounded-full inline-block mb-2">
              AI Concierge Pick
            </span>
            <h3 className="text-xl font-bold text-[#00174b] mb-1.5 relative z-10">
              Tailored For You: Hampi
            </h3>
            <p className="text-xs text-[#00174b]/80 mb-5 relative z-10 leading-relaxed">
              Based on your passion for UNESCO heritage architecture and temple stone carvings, explore the ancient Vijayanagara ruins.
            </p>
            <button
              onClick={() => onNavigate("plan")}
              id="explore-hampi-btn"
              className="bg-[#004ac6] hover:bg-[#003ea8] text-white font-semibold text-xs px-4 py-2.5 rounded-xl transition-all shadow-xs relative z-10 w-full flex items-center justify-center gap-2"
            >
              <span>Plan Hampi Itinerary</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Quick AI Concierge Trigger Card */}
          <div 
            onClick={onOpenConcierge}
            className="glass-panel p-5 rounded-2xl border border-white cursor-pointer hover:shadow-md transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#004ac6] to-[#006c49] flex items-center justify-center text-white shadow-xs">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-[#191c1e] group-hover:text-[#004ac6] transition-colors">
                  Need Personalized Ideas?
                </h4>
                <p className="text-xs text-[#737686]">
                  Ask AI for budget routes, trains, and hidden gems
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Action Button (+ Plan Trip) */}
      <button
        onClick={() => onNavigate("plan")}
        id="home-fab-plan-trip"
        className="fixed bottom-20 right-4 md:bottom-8 md:right-8 bg-gradient-to-r from-[#004ac6] to-[#006c49] text-white rounded-full p-4 shadow-lg hover:shadow-xl hover:scale-105 active:scale-95 transition-all z-40 flex items-center justify-center group cursor-pointer"
        title="Plan New Trip"
      >
        <Plus className="w-6 h-6" />
        <span className="max-w-0 overflow-hidden whitespace-nowrap group-hover:max-w-xs transition-all duration-300 ease-in-out text-sm font-semibold pl-0 group-hover:pl-2">
          Plan Trip
        </span>
      </button>
    </div>
  );
};
