import React from "react";
import { ViewType, Trip } from "../types";
import { 
  Compass, 
  MapPin, 
  Calendar, 
  Users, 
  CloudSun, 
  ArrowRight, 
  Share2, 
  Plus, 
  Sparkles,
  Heart,
  ExternalLink
} from "lucide-react";

interface MyTripsViewProps {
  trips: Trip[];
  onNavigate: (view: ViewType) => void;
  onSelectTrip: (trip: Trip) => void;
}

export const MyTripsView: React.FC<MyTripsViewProps> = ({ 
  trips, 
  onNavigate,
  onSelectTrip 
}) => {
  const ongoingTrip = trips.find(t => t.status === "ongoing") || trips[0];
  const upcomingTrips = trips.filter(t => t.status !== "ongoing");

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#191c1e] tracking-tight">
            My Journeys
          </h1>
          <p className="text-xs sm:text-sm text-[#737686] mt-0.5">
            Manage your ongoing and scheduled expeditions across India
          </p>
        </div>

        <button
          onClick={() => onNavigate("plan")}
          id="my-trips-plan-new-btn"
          className="self-start sm:self-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#004ac6] to-[#006c49] text-white text-xs font-bold shadow-xs hover:shadow-md transition-all flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Plan Another Adventure</span>
        </button>
      </div>

      {/* Ongoing Trip Hero Card */}
      {ongoingTrip && (
        <div className="relative rounded-3xl overflow-hidden shadow-md border border-white/50 group">
          <div 
            className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 group-hover:scale-[1.02]"
            style={{
              backgroundImage: `url('${ongoingTrip.imageUrl}')`
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/20" />

          <div className="relative z-10 p-6 sm:p-8 md:p-10 flex flex-col justify-between min-h-[340px] text-white">
            {/* Top row */}
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ba1a1a] text-white text-xs font-bold tracking-wide uppercase shadow-xs">
                  <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                  Live Expedition
                </span>
                <span className="glass-panel text-white text-xs px-3 py-1 rounded-full bg-white/20">
                  {ongoingTrip.temperature || "28°C"} • {ongoingTrip.weatherCondition || "Sunny"}
                </span>
              </div>

              <div className="glass-panel text-white rounded-full p-2 bg-white/20">
                <Heart className="w-4 h-4 fill-white" />
              </div>
            </div>

            {/* Bottom Content */}
            <div className="space-y-4">
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-1.5 text-xs text-white/80">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {ongoingTrip.dateRange}
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" />
                    {ongoingTrip.travelersText}
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white">
                  {ongoingTrip.title}
                </h2>
              </div>

              {/* Progress Bar */}
              <div className="space-y-1.5 max-w-md">
                <div className="flex justify-between text-xs font-semibold text-white/90">
                  <span>Day {ongoingTrip.currentDay || 4} of {ongoingTrip.totalDays}</span>
                  <span>{Math.round(((ongoingTrip.currentDay || 4) / ongoingTrip.totalDays) * 100)}% Completed</span>
                </div>
                <div className="w-full h-2 rounded-full bg-white/30 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-[#6ffbbe] to-[#2563eb] rounded-full transition-all duration-700" 
                    style={{ width: `${((ongoingTrip.currentDay || 4) / ongoingTrip.totalDays) * 100}%` }}
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => {
                    onSelectTrip(ongoingTrip);
                    onNavigate("itinerary");
                  }}
                  id="ongoing-view-itinerary-btn"
                  className="px-5 py-2.5 rounded-xl bg-white text-[#004ac6] hover:bg-white/95 font-bold text-xs shadow-xs transition-all flex items-center gap-2"
                >
                  <span>View Itinerary</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => onNavigate("budget")}
                  id="ongoing-view-expenses-btn"
                  className="px-4 py-2.5 rounded-xl glass-panel bg-white/20 text-white hover:bg-white/30 font-semibold text-xs transition-all flex items-center gap-1.5"
                >
                  <span>Expenses: ₹{(ongoingTrip.totalBudget).toLocaleString("en-IN")}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Upcoming Trips Section */}
      <section className="space-y-4">
        <h2 className="text-xl sm:text-2xl font-bold text-[#191c1e]">
          Upcoming Expeditions
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {upcomingTrips.map((trip) => (
            <div
              key={trip.id}
              onClick={() => {
                onSelectTrip(trip);
                onNavigate("itinerary");
              }}
              id={`upcoming-trip-card-${trip.id}`}
              className="bg-white rounded-2xl border border-black/5 overflow-hidden shadow-xs hover:shadow-md transition-all group cursor-pointer flex flex-col sm:flex-row"
            >
              <div className="sm:w-48 h-48 sm:h-auto relative overflow-hidden bg-[#eceef0] shrink-0">
                <img 
                  src={trip.imageUrl} 
                  alt={trip.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-xs text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                  {trip.temperature || "24°C"}
                </div>
              </div>

              <div className="p-5 flex flex-col justify-between flex-1 space-y-3">
                <div>
                  <div className="flex justify-between items-start mb-1">
                    <div className="flex gap-1.5 flex-wrap">
                      {trip.tags.map(t => (
                        <span key={t} className="text-[10px] font-bold bg-[#dbe1ff] text-[#004ac6] px-2 py-0.5 rounded-full">
                          {t}
                        </span>
                      ))}
                    </div>
                    <span className="text-xs font-bold text-[#006c49]">
                      ₹{trip.totalBudget.toLocaleString("en-IN")}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-[#191c1e] group-hover:text-[#004ac6] transition-colors">
                    {trip.title}
                  </h3>

                  <div className="text-xs text-[#737686] space-y-1 mt-1">
                    <div className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{trip.dateRange}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5" />
                      <span>{trip.travelersText} • {trip.transportMode || "Flight"}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-black/5 flex items-center justify-between text-xs text-[#004ac6] font-semibold">
                  <span>Open Itinerary & Map</span>
                  <ExternalLink className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
