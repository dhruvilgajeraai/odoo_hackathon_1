import React from "react";
import { ViewType } from "../types";
import { 
  MapPin, 
  CloudSun, 
  Sparkles, 
  ShieldCheck, 
  User, 
  Calendar, 
  Wallet, 
  Compass, 
  Search, 
  Home, 
  LogIn 
} from "lucide-react";

interface NavbarProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  onOpenAuth: () => void;
  onOpenConcierge: () => void;
  isLoggedIn: boolean;
  userEmail: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenAuth,
  onOpenConcierge,
  isLoggedIn,
  userEmail,
}) => {
  const navItems: { id: ViewType; label: string; icon: React.ReactNode }[] = [
    { id: "home", label: "Home", icon: <Home className="w-4 h-4" /> },
    { id: "plan", label: "Explore & Plan", icon: <Search className="w-4 h-4" /> },
    { id: "trips", label: "Trips", icon: <Compass className="w-4 h-4" /> },
    { id: "itinerary", label: "Itinerary", icon: <MapPin className="w-4 h-4" /> },
    { id: "budget", label: "Budget", icon: <Wallet className="w-4 h-4" /> },
    { id: "calendar", label: "Calendar", icon: <Calendar className="w-4 h-4" /> },
    { id: "admin", label: "Analytics", icon: <ShieldCheck className="w-4 h-4" /> },
    { id: "profile", label: "Profile", icon: <User className="w-4 h-4" /> },
  ];

  return (
    <header className="bg-white/80 backdrop-blur-xl docked full-width top-0 sticky z-50 border-b border-white/40 shadow-xs">
      <div className="flex justify-between items-center px-4 md:px-8 py-3.5 w-full max-w-7xl mx-auto">
        {/* Brand Logo */}
        <div 
          onClick={() => onNavigate("landing")}
          className="flex items-center gap-2 cursor-pointer hover:opacity-90 transition-all active:scale-95 group"
          id="navbar-logo"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#004ac6] to-[#006c49] flex items-center justify-center text-white shadow-sm group-hover:shadow-md transition-shadow">
            <MapPin className="w-5 h-5 fill-white" />
          </div>
          <div className="flex flex-col">
            <span className="font-bold text-xl tracking-tight bg-gradient-to-r from-[#004ac6] via-[#2563eb] to-[#006c49] bg-clip-text text-transparent">
              GlobeTrotter
            </span>
            <span className="text-[10px] font-medium text-[#737686] -mt-1 tracking-wider uppercase">
              Incredible India
            </span>
          </div>
        </div>

        {/* Desktop Nav Items */}
        <nav className="hidden lg:flex items-center gap-1.5 font-medium text-sm text-[#434655]">
          {navItems.map((item) => {
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                id={`nav-link-${item.id}`}
                className={`px-3 py-1.5 rounded-full transition-all flex items-center gap-1.5 ${
                  isActive
                    ? "bg-[#004ac6] text-white font-semibold shadow-xs"
                    : "hover:bg-black/5 text-[#434655] hover:text-[#191c1e]"
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Action cluster */}
        <div className="flex items-center gap-2 md:gap-3">
          {/* AI Concierge Button */}
          <button
            onClick={onOpenConcierge}
            id="nav-ai-concierge-btn"
            title="Ask AI Travel Concierge"
            className="px-3 py-1.5 rounded-full bg-gradient-to-r from-[#dbe1ff] to-[#6ffbbe]/40 text-[#004ac6] hover:shadow-xs transition-all border border-[#004ac6]/20 flex items-center gap-1.5 text-xs font-semibold"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#004ac6] animate-pulse" />
            <span className="hidden sm:inline">AI Concierge</span>
          </button>

          {/* Live Weather Indicator */}
          <div 
            onClick={() => onNavigate("home")}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/70 border border-white/60 text-[#191c1e] text-xs font-medium cursor-pointer hover:bg-white transition-colors"
            title="Live Weather: Delhi 32°C"
          >
            <CloudSun className="w-4 h-4 text-[#bc4800]" />
            <span>32°C</span>
          </div>

          {/* User Status / Login */}
          {isLoggedIn ? (
            <div 
              onClick={() => onNavigate("profile")}
              className="flex items-center gap-2 pl-1 cursor-pointer group"
              id="nav-profile-pill"
            >
              <div className="w-8 h-8 rounded-full ring-2 ring-[#004ac6]/30 overflow-hidden shadow-xs group-hover:ring-[#004ac6] transition-all">
                <img 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuAYsP0b3RyNluqC_k4xfdDhWB4WPQlIqhRTTiARSAtxCRVfj0jrtphYwN_vD09AW_QCM9vFFk7nXkfenoxQAz6-yJZ3ZuSZaU7zL9x22Vbn8PGoK3sJdO_WzR82EMsUg3RRvpP3SSDmUCE8nyv91nmUoF4-w9nE6JGnI2h_bC60DZxaHRm6064_OAYPEiAfO-aFOoXLOjSkDy72zhEGqA3YXpwpxWvUh4BX6WaeedbKGet9L5LHX0TW" 
                  alt="Aisha" 
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="hidden md:inline text-xs font-semibold text-[#191c1e] max-w-[100px] truncate">
                Aisha
              </span>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              id="nav-signin-btn"
              className="px-3.5 py-1.5 rounded-full bg-[#004ac6] text-white text-xs font-semibold flex items-center gap-1.5 hover:bg-[#2563eb] transition-all shadow-xs"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
