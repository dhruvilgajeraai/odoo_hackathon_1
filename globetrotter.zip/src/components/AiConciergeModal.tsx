import React, { useState } from "react";
import { 
  X, 
  Sparkles, 
  Send, 
  MapPin, 
  Compass, 
  Bot, 
  User, 
  Loader2 
} from "lucide-react";

interface AiConciergeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPlanTripShortcut: (destination: string) => void;
}

interface ChatMessage {
  id: string;
  sender: "user" | "concierge";
  text: string;
  timestamp: string;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: "m-1",
    sender: "concierge",
    text: "Namaste! I am your GlobeTrotter AI Concierge, specialized in Incredible India travel. Looking for royal palace retreats in Rajasthan, serene backwater houseboats in Kerala, or high-altitude Himalayan trekking routes? How can I assist your journey today?",
    timestamp: "Just now",
  },
];

export const AiConciergeModal: React.FC<AiConciergeModalProps> = ({
  isOpen,
  onClose,
  onPlanTripShortcut,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isLoading) return;

    const userText = inputMessage.trim();
    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: "user",
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputMessage("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/concierge/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userText }),
      });

      const resJson = await response.json();
      const reply = resJson.reply || "I'm ready to craft an exquisite itinerary for your journey in India!";

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: "concierge",
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      const fallbackMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: "concierge",
        text: `Great choice! Exploring ${userText} in India offers incredible culture, delectable cuisine, and rich heritage. Would you like me to generate a complete day-by-day itinerary with budget estimation?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickPrompts = [
    "Best 5-day Golden Triangle route",
    "Luxury Kerala Houseboat advice",
    "Hidden mountain spots in Himachal",
    "Must-try Delhi & Mumbai street food",
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/60 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Chat Container */}
      <div className="relative w-full max-w-xl h-[85vh] max-h-[640px] bg-white/95 backdrop-blur-2xl rounded-3xl shadow-2xl border border-white z-10 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#004ac6] to-[#006c49] text-white flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white ring-1 ring-white/40">
              <Sparkles className="w-5 h-5 text-[#6ffbbe] animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-sm">GlobeTrotter AI Concierge</h3>
              <span className="text-[11px] text-white/80 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#6ffbbe] animate-ping" />
                Live Gemini Travel Assistant
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            id="concierge-modal-close-btn"
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Area */}
        <div className="flex-1 p-4 sm:p-5 overflow-y-auto space-y-4 text-xs">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
            >
              {msg.sender === "concierge" && (
                <div className="w-8 h-8 rounded-full bg-[#dbe1ff] text-[#004ac6] flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[82%] rounded-2xl p-3.5 leading-relaxed space-y-1 ${
                  msg.sender === "user"
                    ? "bg-[#004ac6] text-white rounded-br-none"
                    : "bg-[#f2f4f6] text-[#191c1e] rounded-bl-none border border-black/5"
                }`}
              >
                <p className="whitespace-pre-line">{msg.text}</p>
                <div
                  className={`text-[9px] ${
                    msg.sender === "user" ? "text-white/70 text-right" : "text-[#737686]"
                  }`}
                >
                  {msg.timestamp}
                </div>
              </div>

              {msg.sender === "user" && (
                <div className="w-8 h-8 rounded-full bg-[#006c49] text-white flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-[#737686] text-xs p-2">
              <Loader2 className="w-4 h-4 animate-spin text-[#004ac6]" />
              <span>AI Concierge is curating recommendations...</span>
            </div>
          )}
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 bg-[#f7f9fb] border-t border-black/5 flex gap-1.5 overflow-x-auto hide-scroll">
          {quickPrompts.map((q) => (
            <button
              key={q}
              onClick={() => setInputMessage(q)}
              className="shrink-0 text-[10px] font-semibold bg-white hover:bg-[#eceef0] text-[#004ac6] border border-[#004ac6]/20 px-2.5 py-1 rounded-full transition-colors"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input Footer */}
        <form onSubmit={handleSend} className="p-3.5 bg-white border-t border-black/5 flex items-center gap-2">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Ask about Indian itineraries, trains, palaces, food..."
            className="flex-1 px-4 py-2.5 rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none text-xs text-[#191c1e] bg-[#f7f9fb] focus:bg-white"
          />

          <button
            type="submit"
            disabled={!inputMessage.trim() || isLoading}
            id="concierge-chat-send-btn"
            className="p-2.5 rounded-xl bg-[#004ac6] hover:bg-[#2563eb] text-white transition-all disabled:opacity-50 cursor-pointer shadow-xs"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
