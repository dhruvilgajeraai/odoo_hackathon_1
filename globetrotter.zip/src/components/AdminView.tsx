import React, { useState } from "react";
import { ViewType } from "../types";
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  ShoppingBag, 
  CreditCard, 
  Sparkles, 
  ArrowUpRight, 
  AlertCircle, 
  Check, 
  Download, 
  ShieldCheck 
} from "lucide-react";
import { 
  ADMIN_KPI_DATA, 
  TOP_STATES, 
  AI_INSIGHTS, 
  REVENUE_MONTHLY, 
  REVENUE_WEEKLY 
} from "../data/mockData";

interface AdminViewProps {
  onNavigate: (view: ViewType) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ onNavigate }) => {
  const [timeframe, setTimeframe] = useState<"monthly" | "weekly">("monthly");
  const [actionDone, setActionDone] = useState<string | null>(null);

  const revenueData = timeframe === "monthly" ? REVENUE_MONTHLY : REVENUE_WEEKLY;

  const handleApplyInsight = (id: string) => {
    setActionDone(id);
    setTimeout(() => setActionDone(null), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#dbe1ff] text-[#004ac6] text-[10px] font-bold uppercase tracking-wider mb-1">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Platform Intelligence</span>
          </div>
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#191c1e] tracking-tight">
            Traveler Analytics & Market Insights
          </h1>
          <p className="text-xs sm:text-sm text-[#737686] mt-0.5">
            Real-time pan-India booking velocities, destination performance, and AI demand predictions
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => alert("Admin Executive Summary exported successfully.")}
            className="px-4 py-2 rounded-xl border border-black/10 bg-white hover:bg-[#f2f4f6] text-xs font-bold text-[#191c1e] transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Download className="w-4 h-4" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl border border-black/5 p-5 shadow-xs space-y-1">
          <div className="flex justify-between items-center text-xs font-bold text-[#737686]">
            <span>TOTAL REVENUE</span>
            <CreditCard className="w-4 h-4 text-[#004ac6]" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#191c1e]">
            {ADMIN_KPI_DATA.totalRevenue}
          </div>
          <div className="text-xs text-[#006c49] font-bold flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>{ADMIN_KPI_DATA.revenueGrowth}</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-black/5 p-5 shadow-xs space-y-1">
          <div className="flex justify-between items-center text-xs font-bold text-[#737686]">
            <span>ACTIVE EXPLORERS</span>
            <Users className="w-4 h-4 text-[#006c49]" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#191c1e]">
            {ADMIN_KPI_DATA.activeUsers}
          </div>
          <div className="text-xs text-[#006c49] font-bold flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>{ADMIN_KPI_DATA.usersGrowth}</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-black/5 p-5 shadow-xs space-y-1">
          <div className="flex justify-between items-center text-xs font-bold text-[#737686]">
            <span>TOTAL BOOKINGS</span>
            <ShoppingBag className="w-4 h-4 text-[#943700]" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#191c1e]">
            {ADMIN_KPI_DATA.totalBookings}
          </div>
          <div className="text-xs text-[#006c49] font-bold flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>{ADMIN_KPI_DATA.bookingsGrowth}</span>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-black/5 p-5 shadow-xs space-y-1">
          <div className="flex justify-between items-center text-xs font-bold text-[#737686]">
            <span>AVG TRIP VALUE</span>
            <Sparkles className="w-4 h-4 text-[#737686]" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-[#191c1e]">
            {ADMIN_KPI_DATA.avgTripValue}
          </div>
          <div className="text-xs text-[#ba1a1a] font-bold flex items-center gap-1">
            <TrendingDown className="w-3.5 h-3.5" />
            <span>{ADMIN_KPI_DATA.avgTripChange}</span>
          </div>
        </div>
      </div>

      {/* Main Grid: Left Chart + Heatmap / Right Top States + AI Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        {/* Left 2 Cols: Revenue Velocity & Activity Heatmap */}
        <div className="lg:col-span-2 space-y-6">
          {/* Revenue Velocity Chart */}
          <div className="bg-white rounded-3xl p-6 border border-black/5 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-[#191c1e]">
                  Revenue Velocity & Booking Volume
                </h2>
                <p className="text-xs text-[#737686]">Aggregate gross volume from travel bookings across India</p>
              </div>

              <div className="flex bg-[#f2f4f6] p-1 rounded-xl">
                <button
                  onClick={() => setTimeframe("monthly")}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                    timeframe === "monthly" ? "bg-white text-[#004ac6] shadow-xs" : "text-[#737686]"
                  }`}
                >
                  Monthly
                </button>
                <button
                  onClick={() => setTimeframe("weekly")}
                  className={`px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                    timeframe === "weekly" ? "bg-white text-[#004ac6] shadow-xs" : "text-[#737686]"
                  }`}
                >
                  Weekly
                </button>
              </div>
            </div>

            {/* Custom SVG / Bar Chart Representation */}
            <div className="h-64 flex items-end justify-between gap-2 sm:gap-6 pt-6 px-2">
              {revenueData.map((item) => (
                <div key={item.label} className="flex-1 flex flex-col items-center gap-2 group h-full justify-end">
                  <span className="text-[10px] font-bold text-[#004ac6] opacity-0 group-hover:opacity-100 transition-opacity">
                    {item.value}
                  </span>
                  <div className="w-full bg-[#f2f4f6] rounded-t-xl overflow-hidden flex items-end h-full">
                    <div
                      className="w-full bg-gradient-to-t from-[#004ac6] to-[#6ffbbe] rounded-t-xl transition-all duration-700 group-hover:brightness-110"
                      style={{ height: item.height }}
                    />
                  </div>
                  <span className="text-xs font-bold text-[#737686]">{item.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* User Activity Heatmap */}
          <div className="bg-white rounded-3xl p-6 border border-black/5 shadow-xs space-y-4">
            <h2 className="text-lg font-bold text-[#191c1e]">
              Pan-India Booking Heatmap by Region
            </h2>
            <p className="text-xs text-[#737686]">Active traveler session concentrations and search traffic</p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-2xl bg-[#004ac6]/15 border border-[#004ac6]/20">
                <div className="text-xs font-bold text-[#004ac6]">Western Hub</div>
                <div className="text-lg font-extrabold text-[#191c1e]">Maharashtra & Goa</div>
                <div className="text-[10px] text-[#006c49] font-semibold mt-1">High Demand (84%)</div>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#004ac6]/15 border border-[#004ac6]/20">
                <div className="text-xs font-bold text-[#004ac6]">Northern Trail</div>
                <div className="text-lg font-extrabold text-[#191c1e]">Delhi & Rajasthan</div>
                <div className="text-[10px] text-[#006c49] font-semibold mt-1">Surging (+38%)</div>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#6ffbbe]/25 border border-[#006c49]/20">
                <div className="text-xs font-bold text-[#006c49]">Southern Belt</div>
                <div className="text-lg font-extrabold text-[#191c1e]">Kerala & Karnataka</div>
                <div className="text-[10px] text-[#006c49] font-semibold mt-1">Steady (71%)</div>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#ffdbcd]/40 border border-[#943700]/20">
                <div className="text-xs font-bold text-[#943700]">Himalayan Circuit</div>
                <div className="text-lg font-extrabold text-[#191c1e]">Himachal & Ladakh</div>
                <div className="text-[10px] text-[#943700] font-semibold mt-1">Seasonal Spike</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Top Performing States & AI Market Alerts */}
        <div className="space-y-6">
          {/* Top States Leaderboard */}
          <div className="bg-white rounded-3xl p-6 border border-black/5 shadow-xs space-y-4">
            <h2 className="text-lg font-bold text-[#191c1e]">
              Top Performing States
            </h2>

            <div className="space-y-3">
              {TOP_STATES.map((st) => (
                <div 
                  key={st.name} 
                  className="flex items-center justify-between p-3 rounded-2xl bg-[#f7f9fb] hover:bg-[#eceef0] transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-full bg-[#004ac6] text-white text-xs font-bold flex items-center justify-center">
                      {st.rank}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-[#191c1e]">{st.name}</div>
                      <div className="text-[10px] text-[#737686]">{st.revenue}</div>
                    </div>
                  </div>

                  <span 
                    className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                      st.isPositive ? "bg-[#6ffbbe]/30 text-[#006c49]" : "bg-[#ba1a1a]/10 text-[#ba1a1a]"
                    }`}
                  >
                    {st.growth}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* AI Insights & Alerts */}
          <div className="bg-white rounded-3xl p-6 border border-black/5 shadow-xs space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#004ac6] animate-pulse" />
              <h2 className="text-lg font-bold text-[#191c1e]">
                AI Market Alerts
              </h2>
            </div>

            <div className="space-y-3">
              {AI_INSIGHTS.map((insight) => (
                <div
                  key={insight.id}
                  className="p-4 rounded-2xl bg-[#f7f9fb] border border-black/5 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-[#004ac6] uppercase tracking-wider bg-[#dbe1ff] px-2 py-0.5 rounded-full">
                      {insight.type.toUpperCase()}
                    </span>
                    <AlertCircle className="w-4 h-4 text-[#004ac6]" />
                  </div>

                  <h4 className="text-xs font-bold text-[#191c1e]">
                    {insight.title}
                  </h4>
                  <p className="text-[11px] text-[#434655] leading-relaxed">
                    {insight.description}
                  </p>

                  {insight.actionText && (
                    <button
                      onClick={() => handleApplyInsight(insight.id)}
                      className="w-full mt-2 py-2 px-3 rounded-xl bg-[#004ac6] hover:bg-[#2563eb] text-white text-[11px] font-bold transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      {actionDone === insight.id ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Applied to Strategy</span>
                        </>
                      ) : (
                        <span>{insight.actionText}</span>
                      )}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
