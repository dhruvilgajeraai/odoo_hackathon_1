import React, { useState } from "react";
import { ViewType, CalendarEvent } from "../types";
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Plane, 
  MapPin, 
  Bell, 
  Sparkles, 
  Clock, 
  Plus 
} from "lucide-react";
import { CALENDAR_EVENTS } from "../data/mockData";

interface CalendarViewProps {
  onNavigate: (view: ViewType) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({ onNavigate }) => {
  const [currentMonth, setCurrentMonth] = useState("October 2023");
  const [selectedDate, setSelectedDate] = useState<number>(12);
  const [events, setEvents] = useState<CalendarEvent[]>(CALENDAR_EVENTS);
  const [showEventModal, setShowEventModal] = useState(false);
  const [newNote, setNewNote] = useState("");

  // October 2023 starts on Sunday (1st) and has 31 days
  const daysInMonth = Array.from({ length: 31 }, (_, i) => i + 1);
  const weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const getEventsForDate = (date: number) => {
    return events.filter(e => e.date === date);
  };

  const selectedDateEvents = getEventsForDate(selectedDate);

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNote.trim()) return;

    const newEv: CalendarEvent = {
      id: `cal-${Date.now()}`,
      date: selectedDate,
      month: "October",
      year: 2023,
      title: newNote,
      type: "reminder",
      badgeText: newNote,
    };

    setEvents([...events, newEv]);
    setNewNote("");
    setShowEventModal(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-8 py-6 md:py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#004ac6] bg-[#dbe1ff] px-2.5 py-0.5 rounded-full inline-block mb-1">
            Trip Timeline
          </span>
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-[#191c1e] tracking-tight">
            Travel Calendar
          </h1>
          <p className="text-xs sm:text-sm text-[#737686] mt-0.5">
            Sync flight departures, hotel reservations, and national Indian holidays
          </p>
        </div>

        {/* Month switcher */}
        <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-2xl border border-black/10 shadow-xs">
          <button 
            className="p-1 rounded-lg hover:bg-[#f2f4f6] text-[#434655] transition-colors"
            title="Previous month"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-sm font-bold text-[#191c1e] min-w-[110px] text-center">
            {currentMonth}
          </span>
          <button 
            className="p-1 rounded-lg hover:bg-[#f2f4f6] text-[#434655] transition-colors"
            title="Next month"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Grid: Calendar Grid (2 Cols) / Event Inspector (1 Col) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
        {/* Calendar Grid */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-5 md:p-6 border border-black/5 shadow-xs space-y-4">
          {/* Weekday headers */}
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-[#737686] pb-2 border-b border-black/5">
            {weekDays.map(d => (
              <div key={d} className="py-1">{d}</div>
            ))}
          </div>

          {/* Days cells */}
          <div className="grid grid-cols-7 gap-2 auto-rows-[90px] sm:auto-rows-[105px]">
            {daysInMonth.map((day) => {
              const dayEvents = getEventsForDate(day);
              const isSelected = selectedDate === day;
              const hasTrip = dayEvents.some(e => e.type === "trip");
              const hasHoliday = dayEvents.some(e => e.type === "holiday");

              return (
                <div
                  key={day}
                  onClick={() => setSelectedDate(day)}
                  id={`calendar-day-${day}`}
                  className={`p-1.5 sm:p-2 rounded-xl border transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden ${
                    isSelected
                      ? "ring-2 ring-[#004ac6] border-transparent bg-[#dbe1ff]/30 shadow-xs"
                      : "border-black/5 hover:border-black/20 bg-white hover:bg-[#f7f9fb]"
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span className={`text-xs font-bold ${isSelected ? "text-[#004ac6]" : "text-[#191c1e]"}`}>
                      {day}
                    </span>
                    {hasHoliday && (
                      <span className="w-1.5 h-1.5 rounded-full bg-[#943700]" title="Holiday" />
                    )}
                  </div>

                  {/* Event pills in cell */}
                  <div className="space-y-1 overflow-hidden">
                    {dayEvents.slice(0, 2).map((ev) => (
                      <div
                        key={ev.id}
                        className={`text-[9px] sm:text-[10px] font-semibold px-1.5 py-0.5 rounded truncate ${
                          ev.type === "holiday"
                            ? "bg-[#ffdbcd] text-[#943700]"
                            : ev.type === "flight"
                            ? "bg-[#6ffbbe] text-[#006c49]"
                            : "bg-[#004ac6] text-white"
                        }`}
                      >
                        {ev.badgeText || ev.title}
                      </div>
                    ))}
                    {dayEvents.length > 2 && (
                      <span className="text-[9px] text-[#737686] font-bold block pl-1">
                        +{dayEvents.length - 2} more
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Sidebar: Selected Day Details & Upcoming */}
        <div className="space-y-6">
          {/* Selected Date Card */}
          <div className="bg-white rounded-3xl p-5 border border-black/5 shadow-xs space-y-4">
            <div className="flex justify-between items-center pb-3 border-b border-black/5">
              <div>
                <span className="text-xs font-bold text-[#737686] uppercase tracking-wider">
                  Selected Day
                </span>
                <h3 className="text-xl font-extrabold text-[#191c1e]">
                  October {selectedDate}, 2023
                </h3>
              </div>
              <button
                onClick={() => setShowEventModal(true)}
                id="add-calendar-event-btn"
                className="p-2 rounded-full bg-[#004ac6] text-white hover:bg-[#2563eb] transition-colors shadow-xs"
                title="Add reminder or note"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {selectedDateEvents.length > 0 ? (
              <div className="space-y-3">
                {selectedDateEvents.map((ev) => (
                  <div 
                    key={ev.id}
                    className="p-3.5 rounded-2xl bg-[#f7f9fb] border border-black/5 space-y-1.5 hover:bg-[#eceef0] transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        ev.type === "holiday" ? "bg-[#ffdbcd] text-[#943700]" : "bg-[#dbe1ff] text-[#004ac6]"
                      }`}>
                        {ev.type.toUpperCase()}
                      </span>
                      {ev.time && (
                        <span className="text-xs text-[#737686] flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {ev.time}
                        </span>
                      )}
                    </div>
                    <h4 className="text-sm font-bold text-[#191c1e]">
                      {ev.title}
                    </h4>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-6 text-xs text-[#737686] space-y-2">
                <CalendarIcon className="w-8 h-8 text-[#737686]/40 mx-auto" />
                <p>No scheduled flights or trips on this date.</p>
              </div>
            )}
          </div>

          {/* Indian Holidays & Festivals Highlight */}
          <div className="bg-[#ffdbcd]/30 rounded-3xl p-5 border border-[#943700]/20 shadow-xs space-y-3">
            <div className="flex items-center gap-2 text-[#943700] font-bold text-xs uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-[#943700]" />
              <span>Indian Festivals & Holidays</span>
            </div>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center py-1 border-b border-[#943700]/10">
                <span className="font-semibold text-[#191c1e]">Gandhi Jayanti</span>
                <span className="text-[#943700] font-bold">Oct 02</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-[#943700]/10">
                <span className="font-semibold text-[#191c1e]">Dussehra / Vijayadashami</span>
                <span className="text-[#943700] font-bold">Oct 24</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="font-semibold text-[#191c1e]">Diwali Deepavali</span>
                <span className="text-[#943700] font-bold">Nov 12</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Add Calendar Event Modal */}
      {showEventModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-black/10 space-y-4">
            <h3 className="text-lg font-bold text-[#191c1e]">
              Add Reminder for Oct {selectedDate}
            </h3>

            <form onSubmit={handleAddNote} className="space-y-3.5">
              <div>
                <label className="text-xs font-bold text-[#737686] block mb-1">Reminder / Note Title</label>
                <input
                  type="text"
                  required
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="e.g. Flight check-in, Taj Mahal e-ticket download"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-black/15 focus:ring-2 focus:ring-[#004ac6] outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-black/10">
                <button
                  type="button"
                  onClick={() => setShowEventModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-[#737686] hover:bg-[#eceef0]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-[#004ac6] text-white hover:bg-[#2563eb]"
                >
                  Save Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
