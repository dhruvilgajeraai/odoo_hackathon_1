import React from "react";
import { ViewType } from "../types";
import { Home, Search, Compass, ShieldCheck, User } from "lucide-react";

interface BottomNavProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentView, onNavigate }) => {
  const tabs: { id: ViewType; label: string; icon: React.ReactNode }[] = [
    { id: "home", label: "Home", icon: <Home className="w-5 h-5" /> },
    { id: "plan", label: "Search", icon: <Search className="w-5 h-5" /> },
    { id: "trips", label: "Trips", icon: <Compass className="w-5 h-5" /> },
    { id: "admin", label: "Insights", icon: <ShieldCheck className="w-5 h-5" /> },
    { id: "profile", label: "Profile", icon: <User className="w-5 h-5" /> },
  ];

  return (
    <nav 
      id="mobile-bottom-nav"
      className="bg-white/85 dark:bg-black/60 backdrop-blur-xl fixed bottom-0 left-0 w-full z-50 rounded-t-2xl border-t border-white/40 shadow-lg flex justify-around items-center px-2 py-2 pb-safe md:hidden"
    >
      {tabs.map((tab) => {
        const isActive = currentView === tab.id;
        return (
          <button
            key={tab.id}
            id={`mobile-tab-${tab.id}`}
            onClick={() => onNavigate(tab.id)}
            className={`flex flex-col items-center justify-center p-1.5 transition-all active:scale-90 ${
              isActive
                ? "bg-[#2563eb]/15 text-[#004ac6] rounded-xl font-semibold px-3"
                : "text-[#434655] hover:text-[#191c1e]"
            }`}
          >
            {tab.icon}
            <span className="text-[11px] mt-0.5">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
